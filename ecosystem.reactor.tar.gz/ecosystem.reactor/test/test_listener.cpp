#include "test_listener.h"

using namespace reactor;

TestListener::TestListener(WebsocketServer* server) {
  server_ = server;
}

void TestListener::handleInput(
    const int sockfd, const unsigned char* data, const int length) {
  log4cpp::Log4cpp::getInstance().debug(
    "reactor tester", "input->sockfd: %d, length:%d, data->%s",
     sockfd, length, (char*)data);

    if (server_)
    server_->send(sockfd, "Hello");
}

void TestListener::handleInput(reactor::Buffer& buffer) {
  const int nreceived = buffer.readableBytes();
  char buff[nreceived];
  int result = buffer.read((unsigned char*)buff, nreceived);
  if (result <= 0) {
    return ;
  }

  log4cpp::Log4cpp::getInstance()
    .debug("reactor tester", "received data...result->%d, buff->%s",
     result, buff);

  fwrite(buff, 1, nreceived, stdout);
  fflush(stdout);
}

void TestListener::handleClose(const int sockfd) {
  log4cpp::Log4cpp::getInstance().debug(
    "reactor tester", "socket %d closed", sockfd);
}

void TestListener::handleTimeout(const int sockfd) {
  log4cpp::Log4cpp::getInstance().debug("reactor tester", "timeout...");
}
