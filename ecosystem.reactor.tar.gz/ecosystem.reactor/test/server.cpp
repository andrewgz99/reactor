#include <iostream>

#include <unistd.h>

#include "log4cpp.h"
#include "tcp_server.h"
#include "secure_client.h"
#include "test_listener.h"
#include "initializer.h"
#include "websocket_client.h"
#include "websocket_server.h"

using namespace std;

using namespace log4cpp;
using namespace reactor;

int main(int argc, char** argv) {
  Log4cpp::getInstance().debug("reactor tester", "reactor tester...%d", 123);

  initialize();

  //SecureClient* client = new SecureClient();
  //WebsocketClient* client = new WebsocketClient();
  WebsocketServer* server = new WebsocketServer(4);

  TestListener* listener = new TestListener(server);

  Log4cpp::getInstance().debug("reactor tester", "start to start...");
  if (!server->start()) {
    Log4cpp::getInstance().debug("reactor tester", "start failed.");

    return -1;
  }

  Log4cpp::getInstance().debug("reactor tester", "start to listen...");
  if (!server->listen("127.0.0.1", 10099, listener)) {
    Log4cpp::getInstance().debug("reactor tester", "listen failed.");

    return -1;
  }

  Log4cpp::getInstance().debug("reactor tester", "start to set timeout...");
  //client->connect("www.taobao.com", 80, listener);

  int count = 0;
  while (count < 16) {
    usleep(1000 * 1000);

    //++count;
  }

  Log4cpp::getInstance().debug("reactor tester", "start to stop...");
  server->stop();

  delete server;

  release();

  return 0;
}
