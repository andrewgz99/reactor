#ifndef __TEST_LISTENER_H__
#define __TEST_LISTENER_H__

#include <stdio.h>

#include "log4cpp.h"

#include "event_listener.h"
#include "buffer.h"

#include "websocket_server.h"

class TestListener : public reactor::EventListener {
public:
  TestListener() {server_ = nullptr;}
  TestListener(reactor::WebsocketServer* server);

  virtual void handleInput(
      const int sockfd, const unsigned char* data, const int length);

  virtual void handleInput(reactor::Buffer& buffer);

  virtual void handleClose(const int sockfd);

  virtual void handleTimeout(const int sockfd);

private:
  reactor::WebsocketServer* server_;
};

#endif/*__TEST_LISTENER_H__*/
