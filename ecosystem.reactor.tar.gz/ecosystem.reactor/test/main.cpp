#include <iostream>

#include <unistd.h>

#include "log4cpp.h"
#include "tcp_client.h"
#include "secure_client.h"
#include "test_listener.h"
#include "initializer.h"
#include "websocket_client.h"

using namespace std;

using namespace log4cpp;
using namespace reactor;

int main(int argc, char** argv) {
  Log4cpp::getInstance().debug("reactor tester", "reactor tester...%d", 123);

  initialize();

  //SecureClient* client = new SecureClient();
  WebsocketClient* client = new WebsocketClient(2);

  TestListener* listener = new TestListener();

  Log4cpp::getInstance().debug("reactor tester", "start to start...");
  if (!client->start()) {
    Log4cpp::getInstance().debug("reactor tester", "start failed.");

    return -1;
  }

  Log4cpp::getInstance().debug("reactor tester", "start to connect...");
  if (!client->connect("127.0.0.1", 10099, "/websocket", listener)) {
    Log4cpp::getInstance().debug("reactor tester", "connect failed.");

    return -1;
  }

  Log4cpp::getInstance().debug("reactor tester", "start to set timeout...");
  client->setTimeout(5000);
  //client->connect("www.taobao.com", 80, listener);

  int count = 0;
  while (count < 16) {
    cout<<"sending data"<<endl;

    if (!client->send("hello")) {

    }

    break ;

    usleep(1000 * 1000);

    ++count;
  }

  usleep(1000 * 1000);

  Log4cpp::getInstance().debug("reactor tester", "start to stop...");
  client->stop();

  delete client;

  release();

  return 0;
}
