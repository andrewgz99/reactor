#include <stdio.h>


typedef struct WebsocketFrameHeader {
  unsigned int fin : 1;
  unsigned int rsv1 : 1;
} __attribute__((packed, aligned(1))) WebsocketFrameHeader;

int main(int argc, char** argv) {
	WebsocketFrameHeader header;

	printf("sizeof header->%d\r\n", sizeof(header));

	printf("sizeof int ->%d\r\n", sizeof(int));

	printf("sizeof long->%d", sizeof(long));

	return 0;
}
