#include <stdio.h>

int binary_conversion(int num)
{
    if (num == 0) {
        return 0;
    }
    else {
        return (num % 2) + 10 * binary_conversion(num / 2);
    }
}

int main(int argc, char** argv) {
  printf("%d", binary_conversion(8));

  return 0;
}
