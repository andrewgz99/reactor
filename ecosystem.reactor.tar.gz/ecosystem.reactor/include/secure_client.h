#ifndef __REACTOR_SECURE_CLIENT_H__
#define __REACTOR_SECURE_CLIENT_H__

#include <stdio.h>

#include <string>

#include "communicator.h"
#include "event_listener.h"

namespace reactor {

class Reactor;

class SecureClient : public Communicator, public EventListener {
public:
  SecureClient();
  virtual ~SecureClient();

  virtual bool start();

  virtual bool send(const std::string& data);

  virtual bool send(const unsigned char* data, const int length);

  virtual void stop();

  virtual bool connect(const std::string& hostname, const int port, EventListener* listener);

  virtual void disconnect();

  void setTimeout(const int milliseconds);
private:
  //event listener interfaces.
  virtual void handleInput(Buffer& buffer);

  virtual int handleRead(unsigned char* data, const int length);

  virtual int handleOutput(const unsigned char* data, const int length);

  virtual void handleTimeout(const int sockfd);

  SecureClient(const SecureClient& other) = delete;
  const SecureClient& operator=(const SecureClient& other) = delete;

  Reactor* reactor_ = nullptr;

  EventListener* listener_ = nullptr;

  void* context_ = nullptr;

  void* secure_handle_ = nullptr;

  int socket_;
};

}

#endif/*__REACTOR_SECURE_CLIENT_H__*/
