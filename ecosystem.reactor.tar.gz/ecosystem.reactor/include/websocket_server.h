#ifndef __REACTOR_WEBSOCKET_SERVER_H__
#define __REACTOR_WEBSOCKET_SERVER_H__

#include <string>
#include <unordered_map>

#include "communicator.h"
#include "event_listener.h"
#include "tcp_server.h"

namespace reactor {

class Reactor;

class WebsocketServer : public Communicator, public EventListener {
public:
  WebsocketServer(const int size);
  virtual ~WebsocketServer();

  virtual bool start();

  virtual bool send(const int sockfd, const std::string& data);

  virtual bool send(const int sockfd, const unsigned char* data, const int length);

  virtual void stop();

  virtual bool listen(
      const std::string& address, const int port, EventListener* listener);

  virtual void handleClose(const int sockfd);
private:
  virtual void handleInput(Buffer& buffer);

  virtual void handleTimeout(const int sockfd);

  virtual void handleError(const int errorId,
          const void* user_data = nullptr, const int length = 0);

  WebsocketServer(const WebsocketServer& other) = delete;
  const WebsocketServer& operator=(const WebsocketServer& other) = delete;

  TCPServer* tcp_server_ = nullptr;

  EventListener* listener_ = nullptr;

  std::unordered_map<int, void*> decoders_map_;

  void* encoder_;
};

}

#endif/*__REACTOR_WEBSOCKET_SERVER_H__*/
