#ifndef __REACTOR_SECURE_SERVER_H__
#define __REACTOR_SECURE_SERVER_H__

#include <string>

#include "communicator.h"

namespace reactor {

class Reactor;

class SecureServer : public Communicator {
public:

private:

};

}

#endif/*__REACTOR_SECURE_SERVER_H__*/
