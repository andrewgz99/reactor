#ifndef __REACTOR_COMMUNICATOR_H__
#define __REACTOR_COMMUNICATOR_H__

#include <string>

#include "event_listener.h"

namespace reactor {

class Communicator {
public:
  virtual bool start() {}

  virtual bool send(const std::string& data) {}

  virtual bool send(const unsigned char* data, const int length) {}

  virtual void stop() {}

  virtual bool connect(const std::string& hostname, const int port, EventListener* listener) {}

  virtual void disconnect() {}

  virtual bool send(const int sockfd, const std::string& data) {}

  virtual bool send(const int sockfd, const unsigned char* data, const int length) {}

  virtual bool listen(
      const std::string& address, const int port, EventListener* listener) {}

  virtual ~Communicator() {}
};

}

#endif/*__REACTOR_COMMUNICATOR_H__*/
