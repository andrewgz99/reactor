#ifndef __REACTOR_BUFFER_H__
#define __REACTOR_BUFFER_H__

namespace reactor {

class Fuel;

class Buffer {
public:
  virtual int copy(unsigned char* data, const int length) = 0;

  virtual int read(unsigned char* data, const int length) = 0;

  virtual int write(const unsigned char* data, const int length) = 0;

  virtual int readableBytes() = 0;

  virtual int writtableBytes() = 0;

  virtual void setFuel(Fuel* fuel) = 0;

  virtual Fuel* getFuel() = 0;

  const int getSocketFd() {
    return sockfd_;
  }

  void setSocketFd(const int sockfd) {
    sockfd_ = sockfd;
  }
private:
  int sockfd_;
};

}

#endif/*__REACTOR_BUFFER_H__*/
