#ifndef __REACTOR_INITIALIZER_H__
#define __REACTOR_INITIALIZER_H__

namespace reactor {

void initialize();

bool isInitialized();

void release();

}

#endif/*__REACTOR_INITIALIZER_H__*/
