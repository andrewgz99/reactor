#ifndef __REACTOR_TCP_CLIENT_H__
#define __REACTOR_TCP_CLIENT_H__

#include <string>

#include "communicator.h"

namespace reactor {

class Reactor;

class TCPClient : public Communicator {
public:
  TCPClient(const int size);
  virtual ~TCPClient();

  virtual bool start();

  virtual bool send(const std::string& data);

  virtual bool send(const unsigned char* data, const int length);

  virtual void stop();

  virtual bool connect(
      const std::string& hostname, const int port, EventListener* listener);

  void setTimeout(const int milliseconds);

  virtual void disconnect();
private:
  TCPClient(const TCPClient& other) = delete;
  const TCPClient& operator=(const TCPClient& other) = delete;

  Reactor* reactor_;

  int socket_;
};

}

#endif/*__REACTOR_TCP_CLIENT_H__*/
