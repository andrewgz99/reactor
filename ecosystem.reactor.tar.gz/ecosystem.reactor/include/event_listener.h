#ifndef __REACTOR_EVENT_LISTENER_H__
#define __REACTOR_EVENT_LISTENER_H__

#include "buffer.h"

namespace reactor {

#define ERROR_ID_WRITE_BUFFER_FULL  (1)
#define ERROR_ID_CONNECTION_CLOSED  (2)

class EventListener {
public:
  virtual void handleAccept(const int sockfd) {}

  virtual void handleInput(
      const int sockfd, const unsigned char* data, const int length) {}

  virtual void handleInput(Buffer& buffer) {}

  virtual int handleRead(unsigned char* data, const int length) { return 0; }

  virtual int handleWrite(unsigned char* data, const int length) { return 0; }

  virtual int handleOutput(const unsigned char* data, const int length) { return 0; }

  virtual void handleTimeout(const int sockfd) {}

  virtual void handleClose(const int sockfd) {}

  virtual void handleError(const int errorId,
          const void* user_data = nullptr, const int length = 0) { return ; }

  virtual ~EventListener() {}
};

}

#endif/*__REACTOR_EVENT_LISTENER_H__*/
