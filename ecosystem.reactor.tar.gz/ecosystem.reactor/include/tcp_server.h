#ifndef __REACTOR_TCP_SERVER_H__
#define __REACTOR_TCP_SERVER_H__

#include <string>

#include "communicator.h"

namespace reactor {

class Reactor;

class TCPServer : public Communicator, public EventListener {
public:
  TCPServer(const int size);
  virtual ~TCPServer();

  virtual bool start();

  virtual bool send(const int sockfd, const std::string& data);

  virtual bool send(const int sockfd, const unsigned char* data, const int length);

  virtual void stop();

  virtual bool listen(
      const std::string& address, const int port, EventListener* listener);

  virtual void handleClose(const int sockfd);
private:
  virtual void handleAccept(const int sockfd);

  virtual void handleInput(Buffer& buffer);

  virtual void handleTimeout(const int sockfd);

  virtual void handleError(const int errorId,
          const void* user_data = nullptr, const int length = 0);

  TCPServer(const TCPServer& other) = delete;
  const TCPServer& operator=(const TCPServer& other) = delete;

  Reactor* reactor_ = nullptr;

  int socket_;

  EventListener* listener_ = nullptr;
};

}

#endif/*__REACTOR_TCP_SERVER_H__*/
