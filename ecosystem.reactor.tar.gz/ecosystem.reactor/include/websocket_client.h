#ifndef __REACTOR_WEBSOCKET_CLIENT_H__
#define __REACTOR_WEBSOCKET_CLIENT_H__

#include <string>

#include "communicator.h"
#include "event_listener.h"

namespace reactor {

class Reactor;
class TCPClient;

class WebsocketClient : public Communicator, public EventListener {
public:
  WebsocketClient(const int size);
  virtual ~WebsocketClient();

  virtual bool start();

  virtual bool send(const std::string& data);

  virtual bool send(const unsigned char* data, const int length);

  virtual void stop();

  virtual bool connect(
      const std::string& hostname, const int port,
      const std::string& path, EventListener* listener);

  void setTimeout(const int milliseconds);

  virtual void disconnect();
private:
  virtual void handleInput(Buffer& buffer);

  virtual int handleRead(unsigned char* data, const int length);

  virtual int handleWrite(unsigned char* data, const int length);

  virtual int handleOutput(const unsigned char* data, const int length);

  virtual void handleTimeout(const int sockfd);

  virtual void handleError(const int errorId,
          const void* user_data = nullptr, const int length = 0);

  WebsocketClient(const WebsocketClient& other) = delete;
  const WebsocketClient& operator=(const WebsocketClient& other) = delete;

  TCPClient* tcp_client_ = nullptr;

  EventListener* listener_ = nullptr;

  std::string request_key_;

  bool handshark_;

  void* decoder_;
  void* encoder_;
};

}

#endif/*__REACTOR_WEBSOCKET_CLIENT_H__*/
