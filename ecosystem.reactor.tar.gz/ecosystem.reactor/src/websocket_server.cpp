#include "websocket_server.h"

#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>

#include <string>

#include "initializer.h"
#include "internal/websocket_encoder.h"
#include "internal/websocket_decoder.h"

using namespace std;

namespace reactor {

void WebsocketServer::handleInput(Buffer& buffer) {
  WebsocketDecoder* decoder =
    (WebsocketDecoder*)decoders_map_[buffer.getSocketFd()];
  if (!decoder) {
    decoder = new WebsocketDecoder();
    decoder->setType(PROT_ID_WS_CODEC_TYPE_SERVER);
    decoders_map_[buffer.getSocketFd()] = (void*)decoder;
  }

  unsigned char out[1024 * 1024];
  int out_length = sizeof(out);

  if (!decoder->initialized()) {
    if (decoder->initialize(buffer)) {
      string accpet_key = decoder->getAcceptKey();

      const std::string response =
"HTTP/1.1 101 Switching Protocols\r\n"
"Upgrade: websocket\r\n"
"Connection: Upgrade\r\n"
"Sec-WebSocket-Accept: " + accpet_key + "\r\n\r\n";

      tcp_server_->send(buffer.getSocketFd(),
        (unsigned char*)response.c_str(), response.length());
    }

    return ;
  }

  if (!decoder->decode(buffer, out, out_length)) {
    //close.
    log4cpp::Log4cpp::getInstance().debug("reactor", "start to close conneciton...");
  }

  listener_->handleInput(buffer.getSocketFd(), out, out_length);
}

void WebsocketServer::handleTimeout(const int sockfd) {
  listener_->handleTimeout(sockfd);
}

void WebsocketServer::handleClose(const int sockfd) {
  decoders_map_[sockfd] = nullptr;
  listener_->handleClose(sockfd);
}

void WebsocketServer::handleError(const int errorId,
        const void* user_data, const int length) {
  listener_->handleError(errorId, user_data, length);
}

WebsocketServer::WebsocketServer(const int size) {
  if (!isInitialized()) {
    return ;
  }

  tcp_server_ = new TCPServer(size);

  encoder_ = new WebsocketEncoder();
  ((WebsocketEncoder*)encoder_)->setType(PROT_ID_WS_CODEC_TYPE_SERVER);
}

WebsocketServer::~WebsocketServer() {
  std::unordered_map<int, void*>::iterator it = decoders_map_.begin();
  for (it; it != decoders_map_.end(); ++it) {
    delete it->second;
  }
  decoders_map_.clear();

  if (tcp_server_) {
    delete tcp_server_;
    tcp_server_ = nullptr;
  }
}

bool WebsocketServer::start() {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  ret_value = tcp_server_->start();

  return ret_value;
}

bool WebsocketServer::send(const int sockfd, const std::string& data) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  unsigned char out[1024 * 1024];
  int out_length = sizeof(out);

  WebsocketDecoder* decoder = (WebsocketDecoder*)decoders_map_[sockfd];

  if (!((WebsocketEncoder*)encoder_)
        ->encodeServer(decoder->getMaskKey(), data, out, out_length)) {
    log4cpp::Log4cpp::getInstance().error("reactor", "encode data failed!");

    return ret_value;
  }

  for (int i = 0; i < out_length; ++i) {
    printf("0x%02x ", out[i]);
  }
  printf("\r\n");

  ret_value = tcp_server_->send(sockfd, out, out_length);

  return ret_value;
}

bool WebsocketServer::send(const int sockfd, const unsigned char* data, const int length) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  ret_value = tcp_server_->send(sockfd, data, length);

  return ret_value;
}

void WebsocketServer::stop() {
  if (!isInitialized()) {
    return ;
  }

  tcp_server_->stop();
}

bool WebsocketServer::listen(
    const std::string& address, const int port, EventListener* listener) {
  bool ret_value = false;

  ret_value = tcp_server_->listen(address, port, this);
  if (ret_value) {
    listener_ = listener;
  }

  return ret_value;
}

}
