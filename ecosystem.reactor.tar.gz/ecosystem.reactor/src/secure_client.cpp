#include "secure_client.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string>
#include <poll.h>
#include <sys/epoll.h>
#include <signal.h>

#include <openssl/bio.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

#include "log4cpp.h"

#include "internal/fuel.h"
#include "impl/simple_buffer.h"
#include "internal/common_utils.h"

#include "internal/reactor_factory.h"
#include "initializer.h"

using namespace log4cpp;

namespace reactor {

extern SSL_CTX* getSSLContext();

//event listener interfaces.
void SecureClient::handleInput(Buffer& buffer) {
  listener_->handleInput(buffer);
}

int SecureClient::handleRead(unsigned char* data, const int length) {
  int ret_value = -1;

  ret_value = SSL_read((SSL*)secure_handle_, data, length);

  return ret_value;
}

int SecureClient::handleOutput(const unsigned char* data, const int length) {
  //Log4cpp::getInstance().debug("reactor", "start to send data to remote...");
  int result =  SSL_write((SSL*)secure_handle_, data, length);

  Log4cpp::getInstance().debug("reactor", "length->%d, result->%d", length, result);

  return result;
}

void SecureClient::handleTimeout(const int sockfd) {
  if (listener_) {
    listener_->handleTimeout(sockfd);
  }
}

bool SecureClient::start() {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  ret_value = reactor_->start();

  return ret_value;
}

bool SecureClient::send(const std::string& data) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  if (socket_ < 0) {
    return ret_value;
  }

  ret_value = reactor_->send(socket_, data);

  return ret_value;
}

bool SecureClient::send(const unsigned char* data, const int length) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  if (socket_ < 0) {
    return ret_value;
  }

  ret_value = reactor_->send(socket_, data, length);

  return ret_value;
}

void SecureClient::stop() {
  if (!isInitialized()) {
    return ;
  }

  if (reactor_) {
    reactor_->stop();
  }
}

bool SecureClient::connect(const std::string& hostname, const int port,
                           EventListener* listener) {
  bool ret_value = false;

  if (!isInitialized()) {
    Log4cpp::getInstance().error("reactor", "reactor not initialized...");

    return ret_value;
  }

  if (socket_ > 0) {
    Log4cpp::getInstance().error("reactor", "already connected...");

    return ret_value;
  }

  if (hostname.empty() || port <= 0 || !listener) {
    Log4cpp::getInstance().error("reactor", "invalid parameters...");

    return ret_value;
  }

  int sock;
  struct sockaddr_in sockaddr;
  struct hostent *host;
  sock = socket(AF_INET,
           SOCK_STREAM,
           0);

  if(sock < 0) {
    return ret_value;
  }

  /* zero buffer */
  memset(&sockaddr, 0, sizeof(sockaddr));
  sockaddr.sin_family = AF_INET;

  Log4cpp::getInstance().debug("reactor tester", "start to get host by name...");
  if((host = gethostbyname(hostname.c_str())) == NULL) {
    Log4cpp::getInstance().error("reactor tester", "get host by name failed...");

    close(sock);
    return ret_value;
  }

  memcpy(&sockaddr.sin_addr,
        host -> h_addr,
        host -> h_length);
  sockaddr.sin_port = htons(port);

  Log4cpp::getInstance().debug("reactor tester",
    "connecting to host...hostname->%s, port->%d", hostname.c_str(), port);
  if(::connect(sock, (struct sockaddr *)&sockaddr, sizeof(sockaddr)) < 0) {
     close(sock);
     return ret_value;
  }

  Log4cpp::getInstance().debug("reactor tester", "connect to remote ok...");

  //make nonblocking.
  int flags = fcntl(sock, F_GETFL, 0);
  if (flags == -1) {
    Log4cpp::getInstance().error("reactor tester", "get flags failed...");

    close(sock);

    return ret_value;
  }
  Log4cpp::getInstance().debug("reactor tester", "get flags ok...");

  flags = flags | O_NONBLOCK;
  fcntl(sock, F_SETFL, flags);

  secure_handle_ = (void*)SSL_new(getSSLContext());
  if (!SSL_set_fd((SSL*)secure_handle_, sock)) {
    Log4cpp::getInstance().error("reactor tester", "set fd failed...");

    ERR_print_errors_fp (stderr);
    close(sock);

    return ret_value;
  }

  Log4cpp::getInstance().debug("reactor tester", "start to loop...");

  SSL_set_connect_state((SSL*)secure_handle_);
  int r = 0;
  int events = POLLIN | POLLOUT | POLLERR;
  while ((r = SSL_do_handshake((SSL*)secure_handle_)) != 1) {
    int err = SSL_get_error((SSL*)secure_handle_, r);
    if (err == SSL_ERROR_WANT_WRITE) {
      events |= POLLOUT;
      events &= ~POLLIN;
      Log4cpp::getInstance().debug("reactor tester", "want to write...");
    } else if (err == SSL_ERROR_WANT_READ) {
      events |= EPOLLIN;
      events &= ~EPOLLOUT;
      Log4cpp::getInstance().debug("reactor tester", "want to read...");
    } else {
      ERR_print_errors_fp(stderr);

      break ;
    }
    struct pollfd pfd;
    pfd.fd = sock;
    pfd.events = events;
    do {
      r = poll(&pfd, 1, 100);
    } while  (r == 0);
  }

  //add fuel.
  Fuel* fuel = new Fuel();
  fuel->setSocket(sock);
  fuel->setType(CommonUtils::FUEL_TYPE_MANAGED);
  fuel->setReadBuffer(new SimpleBuffer());
  fuel->getReadBuffer()->setFuel(fuel);
  fuel->setWriteBuffer(new SimpleBuffer());
  fuel->getWriteBuffer()->setFuel(fuel);
  fuel->setListener(this);
  listener_ = listener;
  reactor_->add(fuel);
  socket_ = sock;

  Log4cpp::getInstance().debug("reactor", "connect to host ok...");

  ret_value = true;

  return ret_value;
}

void SecureClient::setTimeout(const int milliseconds) {
  if (!isInitialized()) {
    return ;
  }

  if (socket_ < 0) {
    return ;
  }

  reactor_->setTimeout(socket_, milliseconds);
}

void SecureClient::disconnect() {
  if (!isInitialized()) {
    return ;
  }

  if (socket_ > 0) {
    reactor_->remove(socket_);
    socket_ = -1;
  }
}

SecureClient::SecureClient() {
  if (!isInitialized()) {
    return ;
  }

  reactor_ = ReactorFactory::createSelectReactor(2);
  socket_ = -1;
}

SecureClient::~SecureClient() {
  if (!isInitialized()) {
    return ;
  }

  if (reactor_) {
    ReactorFactory::destoryReactor(reactor_);
    reactor_ = nullptr;
  }
}

}
