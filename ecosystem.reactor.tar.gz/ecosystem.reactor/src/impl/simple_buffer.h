#ifndef __REACTOR_SIMPLE_BUFFER_H__
#define __REACTOR_SIMPLE_BUFFER_H__

#include <string.h>
#include <stdlib.h>

#include "buffer.h"

namespace reactor {

class SimpleBuffer : public Buffer {
public:
  SimpleBuffer() {
    memset(buffer_, 0x00, sizeof(buffer_));
    index_ = 0;
  }

  ~SimpleBuffer() {

  }

  virtual int copy(unsigned char* data, const int length) {
    int ret_value =-1;

    if (!data || length <= 0) {
      return ret_value;
    }

    if (index_ <= 0) {
      return ret_value;
    }

    int nread = length;
    if (nread > index_) {
      nread = index_;
    }

    printf("%u: copy index_->%d\r\n", this, index_);
    memcpy(data, buffer_, nread);

    ret_value = nread;

    return ret_value;
  }

  virtual int read(unsigned char* data, const int length) {
    int ret_value =-1;

    if (!data || length <= 0) {
      return ret_value;
    }

    if (index_ <= 0) {
      return ret_value;
    }

    int nread = length;
    if (nread > index_) {
      nread = index_;
    }

    printf("%u: read before index_->%d, nread->%d\r\n",
      this, index_, nread);
    memcpy(data, buffer_, nread);
    index_ -= nread;
    printf("%u: read index_->%d\r\n", this, index_);
    if (index_ > 0) {
      memmove(buffer_, buffer_ + nread, index_);
    }

    ret_value = nread;

    return ret_value;
  }

  virtual int write(const unsigned char* data, const int length) {
    int ret_value =-1;

    if (!data || length <= 0) {
      return ret_value;
    }

    int nwrite = length;
    if (nwrite > writtableBytes()) {
      nwrite = writtableBytes();
    }

    printf("%u: write before->index_->%d, nwrite->%d\r\n",
     this, index_, nwrite);

    memcpy(buffer_ + index_, data, nwrite);
    index_ += nwrite;

    printf("%u: write index_->%d\r\n", this, index_);

    ret_value = nwrite;

    return ret_value;
  }

  virtual int readableBytes() {
    int ret_value =-1;

    ret_value = index_;

    return ret_value;
  }

  virtual int writtableBytes() {
    int ret_value =-1;

    ret_value = size_ - index_;

    return ret_value;
  }

  virtual void setFuel(Fuel* fuel) {
    fuel_ = fuel;
  }

  virtual Fuel* getFuel() {
    return fuel_;
  }

private:
  unsigned char buffer_[1024 * 100];
  const int size_ = 1024 * 100;
  int index_;

  Fuel* fuel_ = nullptr;
};

}

#endif/*__REACTOR_SIMPLE_BUFFER_H__*/
