#ifndef __REACTOR_EPOLL_REACTOR_H__
#define __REACTOR_EPOLL_REACTOR_H__

#include <thread>
#include <vector>

#include "internal/base_container.h"
#include "internal/reactor.h"

namespace reactor {

class ReactorFactory;

class Container;

class EPollReactor : public Reactor {
public:
  friend ReactorFactory;

  EPollReactor(const int size);
  virtual ~EPollReactor();

  virtual bool start();

  virtual bool add(Fuel* fuel);

  virtual void setTimeout(const int sockfd, const int milliseconds);

  virtual bool send(const int sockfd, const std::string& data);

  virtual bool send(const int sockfd, const unsigned char* data, const int length);

  virtual void remove(const int sockfd);

  virtual void stop();
  private:
  EPollReactor() = delete;

  BaseContainer** containers_ = nullptr;
  int size_;

  std::vector<std::thread*> threads_vector_;
};

}

#endif/*__REACTOR_EPOLL_REACTOR_H__*/
