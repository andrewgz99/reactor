#include "select_reactor.h"

#include "log4cpp.h"
#include "internal/container.h"

using namespace log4cpp;

namespace reactor {

void SelectReactor::setTimeout(const int sockfd, const int milliseconds) {
  if (!containers_) {
    Log4cpp::getInstance().error("reactor", "not started...");

    return ;
  }

  if (sockfd < 0) {
    Log4cpp::getInstance().error("reactor", "socket is invalid...");

    return ;
  }

  int index = sockfd % size_;
  if (!containers_[index]->isRunning()) {
    Log4cpp::getInstance().error("reactor", "container stopped...");

    return ;
  }
  containers_[index]->setTimeout(sockfd, milliseconds);
}

bool SelectReactor::send(const int sockfd, const std::string& data) {
  bool ret_value = false;

  if (!containers_) {
    Log4cpp::getInstance().error("reactor", "not started...");

    return ret_value;
  }

  if (sockfd < 0) {
    Log4cpp::getInstance().error("reactor", "socket is invalid...");

    return ret_value;
  }

  if (data.empty()) {
    Log4cpp::getInstance().error("reactor", "data is empty...");

    return ret_value;
  }

  int index = sockfd % size_;
  if (!containers_[index]->isRunning()) {
    Log4cpp::getInstance().error("reactor", "container stopped...");

    return ret_value;
  }
  ret_value = containers_[index]->send(sockfd, data);

  return ret_value;
}

bool SelectReactor::send(const int sockfd, const unsigned char* data, const int length) {
  bool ret_value = false;

  if (!containers_) {
    Log4cpp::getInstance().error("reactor", "not started...");

    return ret_value;
  }

  if (sockfd < 0) {
    Log4cpp::getInstance().error("reactor", "socket is invalid...");

    return ret_value;
  }

  if (!data || length <= 0) {
    Log4cpp::getInstance().error("reactor", "data is nullptr...");

    return ret_value;
  }

  int index = sockfd % size_;
  if (!containers_[index]->isRunning()) {
    Log4cpp::getInstance().error("reactor", "container stopped...");

    return ret_value;
  }
  ret_value = containers_[index]->send(sockfd, data, length);

  return ret_value;
}

bool SelectReactor::add(Fuel* fuel) {
  bool ret_value = false;

  if (!containers_) {
    Log4cpp::getInstance().error("reactor", "not started...");

    return ret_value;
  }

  if (!fuel) {
    Log4cpp::getInstance().error("reactor", "fuel is nullptr...");

    return ret_value;
  }

  if (fuel->getSocket() < 0) {
    Log4cpp::getInstance().error("reactor", "socket is invalid...");

    return ret_value;
  }

  int index = fuel->getSocket() % size_;
  ret_value = containers_[index]->add(fuel);

  return ret_value;
}

void SelectReactor::remove(const int sockfd) {
  if (!containers_) {
    Log4cpp::getInstance().error("reactor", "not started...");

    return ;
  }

  if (sockfd < 0) {
    Log4cpp::getInstance().error("reactor", "socket is invalid...");

    return ;
  }

  int index = sockfd % size_;
  containers_[index]->remove(sockfd);
}

bool SelectReactor::start() {
  bool ret_value = false;

  for (int i = 0; i < size_; ++i) {
    containers_[i]->setRunning(true);

    threads_vector_.push_back(new std::thread(&Container::loop, containers_[i]));
  }

  Log4cpp::getInstance().debug("reactor", "start select reactor ok...");

  ret_value = true;

  return ret_value;
}

void SelectReactor::stop() {
  Log4cpp::getInstance().debug("reactor", "SelectReactor::stop-->");

  try {
    Log4cpp::getInstance().debug("reactor", "size_->%d", size_);

    for (int i = 0; i < size_; ++i) {
      if (containers_[i]) {
        if (containers_[i]->isRunning()) {
          containers_[i]->setRunning(false);

          if (threads_vector_[i]->joinable()) {
            threads_vector_[i]->join();

            delete threads_vector_[i];
            threads_vector_[i] = nullptr;
          }

          Log4cpp::getInstance().debug("reactor", "setted stop running...");
        }
      }
    }

    threads_vector_.clear();

    Log4cpp::getInstance().debug("reactor", "all thread stopped...");
  } catch(std::exception& e) {
    Log4cpp::getInstance().error("reactor", "exception->%s", e.what());
  }

  Log4cpp::getInstance().debug("reactor", "select reactor stopped...");
}

SelectReactor::SelectReactor(const int size) {
  size_ = size;
  if (size_ <= 0) {
    size_ = 0;

    Log4cpp::getInstance().error("reactor", "invalid size...");

    return ;
  }

  if (size_ > 10) {
    size_ = 4;
  }

  containers_ = new Container*[size_];
  if (!containers_) {
    Log4cpp::getInstance().error("reactor", "out of memory...");

    return ;
  }
  for (int i = 0; i < size_; ++i) {
    containers_[i] = new Container();

    containers_[i]->initialize();
  }
}

SelectReactor::~SelectReactor() {
  Log4cpp::getInstance().debug("reactor", "SelectReactor destroy");

  Log4cpp::getInstance().debug("reactor", "size_->%d", size_);

  for (int i = 0; i < size_; ++i) {
    delete containers_[i];
    containers_[i] = nullptr;
  }

  delete [] containers_;
  containers_ = nullptr;
}

}
