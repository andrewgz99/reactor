#include "tcp_client.h"

#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>

#include "log4cpp.h"

#include "internal/fuel.h"
#include "impl/simple_buffer.h"
#include "internal/common_utils.h"

#include "internal/reactor_factory.h"
#include "initializer.h"

using namespace log4cpp;

namespace reactor {

bool TCPClient::send(const std::string& data) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  if (socket_ < 0) {
    return ret_value;
  }

  ret_value = reactor_->send(socket_, data);

  return ret_value;
}

bool TCPClient::send(const unsigned char* data, const int length) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  if (socket_ < 0) {
    return ret_value;
  }

  ret_value = reactor_->send(socket_, data, length);

  return ret_value;
}

bool TCPClient::start() {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  ret_value = reactor_->start();

  return ret_value;
}

void TCPClient::stop() {
  if (!isInitialized()) {
    return ;
  }

  reactor_->stop();
}

bool TCPClient::connect(const std::string& hostname, const int port,
             EventListener* listener) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  if (socket_ > 0) {
    Log4cpp::getInstance().debug("reactor", "already connected...");

    return ret_value;
  }

  if (hostname.empty() || port <= 0 || !listener) {
    Log4cpp::getInstance().debug("reactor", "invalid parameters...");

    return ret_value;
  }

  int sock;
  struct sockaddr_in sockaddr;
  struct hostent *host;
  sock = socket(AF_INET,
           SOCK_STREAM,
           0);

  if(sock < 0) {
    return ret_value;
  }

  /* zero buffer */
  memset(&sockaddr, 0, sizeof(sockaddr));
  sockaddr.sin_family = AF_INET;

  if((host = gethostbyname(hostname.c_str())) == NULL) {
     close(sock);
     return ret_value;
  }

  memcpy(&sockaddr.sin_addr,
        host -> h_addr,
        host -> h_length );
  sockaddr.sin_port = htons(port);

  if(::connect(sock, (struct sockaddr *)&sockaddr, sizeof(sockaddr)) < 0) {
     close(sock);
     return ret_value;
  }

  //make nonblocking.
  int flags = fcntl(sock, F_GETFL, 0);
  if (flags == -1) {
    close(sock);

    return ret_value;
  }
  flags = flags | O_NONBLOCK;
  fcntl(sock, F_SETFL, flags);

  //add fuel.
  Fuel* fuel = new Fuel();
  fuel->setSocket(sock);
  fuel->setType(CommonUtils::FUEL_TYPE_RAW);
  fuel->setReadBuffer(new SimpleBuffer());
  fuel->getReadBuffer()->setFuel(fuel);
  fuel->setWriteBuffer(new SimpleBuffer());
  fuel->getWriteBuffer()->setFuel(fuel);
  fuel->setListener(listener);
  reactor_->add(fuel);
  socket_ = sock;

  Log4cpp::getInstance().debug("reactor", "connect to host ok...");

  ret_value = true;

  return ret_value;
}

void TCPClient::setTimeout(const int milliseconds) {
  if (!isInitialized()) {
    return ;
  }

  if (socket_ < 0) {
    return ;
  }

  reactor_->setTimeout(socket_, milliseconds);
}

void TCPClient::disconnect() {
  if (!isInitialized()) {
    return ;
  }

  if (socket_ > 0) {
    reactor_->remove(socket_);
    socket_ = -1;
  }
}

TCPClient::TCPClient(const int size) {
  if (!isInitialized()) {
    return ;
  }

  reactor_ = ReactorFactory::createSelectReactor(size);
  socket_ = -1;
}

TCPClient::~TCPClient() {
  if (!isInitialized()) {
    return ;
  }

  if (reactor_) {
    ReactorFactory::destoryReactor(reactor_);
    reactor_ = nullptr;
  }
}

}
