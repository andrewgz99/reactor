#include "initializer.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <openssl/err.h>
#include <openssl/ssl.h>

#include "log4cpp.h"

using namespace log4cpp;

namespace reactor {

static SSL_CTX* g_ssl_context_ = nullptr;

extern SSL_CTX* getSSLContext();

SSL_CTX* getSSLContext() {
  return g_ssl_context_;
}

void initialize() {
  if (g_ssl_context_) {
    return ;
  }

  g_ssl_context_ = SSL_CTX_new (SSLv23_client_method());
  if (g_ssl_context_) {
    Log4cpp::getInstance().debug("reactor", "reactor initialized ok...");
  } else {
    Log4cpp::getInstance().error("reactor", "reactor initialized failed...");
  }
}

bool isInitialized() {
  if (g_ssl_context_) {
    return true;
  }

  return false;
}

void release() {
  if (g_ssl_context_) {
    SSL_CTX_free (g_ssl_context_);
    g_ssl_context_ = nullptr;
  }
}

}
