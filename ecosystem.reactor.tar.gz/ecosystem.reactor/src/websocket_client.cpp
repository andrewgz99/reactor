#include "websocket_client.h"

#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>

#include <string>

#include "log4cpp.h"

#include "internal/fuel.h"
#include "impl/simple_buffer.h"
#include "internal/common_utils.h"
#include "tcp_client.h"

#include "internal/reactor_factory.h"
#include "initializer.h"
#include "internal/websocket_decoder.h"
#include "internal/websocket_encoder.h"

using namespace std;

using namespace log4cpp;

namespace reactor {

void WebsocketClient::handleError(const int errorId,
        const void* user_data, const int length) {
  if (ERROR_ID_WRITE_BUFFER_FULL == errorId) {
    usleep(1000 * 1000 * 100);

    int result = tcp_client_->send((const unsigned char*)user_data, length);
  } else if (ERROR_ID_CONNECTION_CLOSED == errorId) {
    tcp_client_->stop();
  }
}

void WebsocketClient::handleInput(Buffer& buffer) {
  log4cpp::Log4cpp::getInstance().debug("reactor", "handleInput-->");

  if (!((WebsocketDecoder*)decoder_)->initialized()) {
    ((WebsocketDecoder*)decoder_)->initialize(buffer);

    return ;
  }

  unsigned char out[1024 * 1024];
  int out_length = sizeof(out);

  if (!((WebsocketDecoder*)decoder_)->decode(buffer, out, out_length)) {
    //close.
    log4cpp::Log4cpp::getInstance().debug("reactor", "start to close conneciton...");
  }

  listener_->handleInput(buffer.getSocketFd(), out, out_length);
}

int WebsocketClient::handleRead(unsigned char* data, const int length) {
  int ret_value = -1;

  log4cpp::Log4cpp::getInstance().debug("reactor", "WebsocketClient::handleRead-->");

  return ret_value;
}

int WebsocketClient::handleWrite(unsigned char* data, const int length) {
  int ret_value = -1;

  log4cpp::Log4cpp::getInstance().debug("reactor", "WebsocketClient::handleWrite-->");

  return ret_value;
}

int WebsocketClient::handleOutput(const unsigned char* data, const int length) {
  int ret_value = -1;

  log4cpp::Log4cpp::getInstance().debug("reactor", "WebsocketClient::handleOutput-->");

  return ret_value;
}

void WebsocketClient::handleTimeout(const int sockfd) {
  log4cpp::Log4cpp::getInstance().debug("reactor", "WebsocketClient::handleTimeout-->");
}

WebsocketClient::WebsocketClient(const int size) {
  if (!isInitialized()) {
    return ;
  }

  tcp_client_ = new TCPClient(size);

  handshark_ = false;
  request_key_ = "";

  encoder_ = (void*)new WebsocketEncoder();
  decoder_ = (void*)new WebsocketDecoder();

  ((WebsocketDecoder*)decoder_)
    ->setType(PROT_ID_WS_CODEC_TYPE_CLIENT);
}

WebsocketClient::~WebsocketClient() {
  if (!isInitialized()) {
    return ;
  }

  if (encoder_) {
    delete (WebsocketEncoder*)encoder_;
    encoder_ = nullptr;
  }
  if (decoder_) {
    delete (WebsocketDecoder*)decoder_;
    decoder_ = nullptr;
  }

  if (tcp_client_) {
    delete tcp_client_;
    tcp_client_ = nullptr;
  }

  handshark_ = false;
  request_key_ = "";
}

bool WebsocketClient::start() {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  ret_value = tcp_client_->start();

  return ret_value;
}

bool WebsocketClient::send(const std::string& data) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  if (data.empty()) {
    log4cpp::Log4cpp::getInstance().error("reactor", "send data is empty!");

    return ret_value;
  }

  if (data.length() > 1024 * 1024 * 1 - 100) {
    log4cpp::Log4cpp::getInstance().error("reactor", "send data's length too long!");

    return ret_value;
  }

  unsigned char out[1024 * 1024];
  int out_length = 0;
  if (!((WebsocketEncoder*)encoder_)
        ->encode(data, out, out_length)) {
    log4cpp::Log4cpp::getInstance().error("reactor", "encode data failed!");

    return ret_value;
  }

  for (int i = 0; i < out_length; ++i) {
    printf("0x%02x ", out[i]);
  }
  printf("\r\n");

  log4cpp::Log4cpp::getInstance().debug(
    "reactor",
    "send data with length->%d", out_length);
  ret_value = tcp_client_->send(out, out_length);

  return ret_value;
}

bool WebsocketClient::send(const unsigned char* data, const int length) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  if (!data || length <= 0) {
    log4cpp::Log4cpp::getInstance().debug("reactor", "send data invalid!");

    return ret_value;
  }

  unsigned char out[1024 * 100];
  int out_length = 0;
  if (!((WebsocketEncoder*)encoder_)
        ->encode(data, length, out, out_length)) {
    log4cpp::Log4cpp::getInstance().debug("reactor", "encode data failed!");

    return ret_value;
  }

  ret_value = tcp_client_->send(out, out_length);

  return ret_value;
}

void WebsocketClient::stop() {
  if (!isInitialized()) {
    return ;
  }

  tcp_client_->stop();
}

bool WebsocketClient::connect(
    const std::string& hostname, const int port,
    const std::string& path, EventListener* listener) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  bool result = tcp_client_->connect(hostname, port, this);
  if (!result) {
    return ret_value;
  }

  //perform handshark.
  request_key_ = "dGhlIHNhbXBsZSBub25jZQ==";
  char handshark_request[1024 * 5];
  snprintf(handshark_request, sizeof(handshark_request) - 1,
"GET %s HTTP/1.1\r\n"
"Host: %s\r\n"
"Upgrade: websocket\r\n"
"Connection: Upgrade\r\n"
"Sec-WebSocket-Key: %s\r\n"
"Origin: %s\r\n"
"Sec-WebSocket-Protocol: push\r\n"
"Sec-WebSocket-Version: 13\r\n\r\n",
path.c_str(), hostname.c_str(), request_key_.c_str(), hostname.c_str()
);
  if (tcp_client_->send(handshark_request)) {
    ret_value = true;
  }

  while (!((WebsocketDecoder*)decoder_)->initialized()) {
    Log4cpp::getInstance().debug("reactor", "not initailized...");

    usleep(1000 * 100);
  }

  listener_ = listener;

  return ret_value;
}

void WebsocketClient::setTimeout(const int milliseconds) {
  if (!isInitialized()) {
    return ;
  }

  tcp_client_->setTimeout(milliseconds);
}

void WebsocketClient::disconnect() {
  if (!isInitialized()) {
    return ;
  }

  tcp_client_->disconnect();
}

}
