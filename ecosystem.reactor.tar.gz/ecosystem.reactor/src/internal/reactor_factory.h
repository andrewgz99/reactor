#ifndef __REACTOR_REACTOR_FACTORY_H__
#define __REACTOR_REACTOR_FACTORY_H__

#include "impl/select_reactor.h"
#include "impl/epoll_reactor.h"

namespace reactor {

class ReactorFactory {
public:
  static Reactor* createEPollReactor(const int size) {
    Reactor* ret_value = nullptr;

    ret_value = new EPollReactor(size);

    return ret_value;
  }

  static Reactor* createSelectReactor(const int size) {
    Reactor* ret_value = nullptr;

    ret_value = new SelectReactor(size);

    return ret_value;
  }

  static void destoryReactor(Reactor* reactor) {
    if (reactor) {
      delete reactor;
      reactor = nullptr;
    }
  }
};

}

#endif/*__REACTOR_REACTOR_FACTORY_H__*/
