#ifndef __REACTOR_EVENT_H__
#define __REACTOR_EVENT_H__

#include <string.h>

#include <string>

namespace reactor {

class Fuel;

class Event {
public:
  static const int EVENT_ID_ADD = 1;
  static const int EVENT_ID_REMOVE = 2;
  static const int EVENT_ID_SEND = 3;
  static const int EVENT_ID_TIMEOUT = 4;

  Event() {
    id_ =0;
    socket_ = 0;
    str_data_ = "";
    bin_data_length_ = 0;
  }

  ~Event() {

  }

  void setSocket(const int sockfd) {
    socket_ = sockfd;
  }

  const int getSocket() {
    return socket_;
  }

  void setFuel(Fuel* fuel) {
    fuel_ = fuel;
  }

  Fuel* getFuel() {
    return fuel_;
  }

  void setData(const std::string& data) {
    str_data_ = data;
  }

  const std::string& getData() {
    return str_data_;
  }

  void setData(const unsigned char* data, const int length) {
    if (!data || length <= 0) {
      return ;
    }

    bin_data_ = new unsigned char[length];
    if (!bin_data_) {
      return ;
    }
    memcpy(bin_data_, data, length);
    bin_data_length_ = length;
  }

  bool getData(unsigned char*& data, int& length) {
    if (!bin_data_ || bin_data_length_ <= 0) {
      return false;
    }
    data = bin_data_;
    length = bin_data_length_;
    return true;
  }

  void setId(const int id) {
    id_ = id;
  }

  const int getId() {
    return id_;
  }

  void setTimeoutInterval(const int timeout_interval) {
    timeout_interval_ = timeout_interval;
  }

  const int getTimeoutInterval() {
    return timeout_interval_;
  }

private:
  int id_;

  int socket_;

  Fuel* fuel_ = nullptr;

  std::string str_data_;

  unsigned char* bin_data_ = nullptr;
  int bin_data_length_;

  int timeout_interval_;
};

}

#endif/*__REACTOR_EVENT_H__*/
