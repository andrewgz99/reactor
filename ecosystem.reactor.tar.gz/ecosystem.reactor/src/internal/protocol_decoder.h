#ifndef __REACTOR_PROTOCOL_DECODER_H__
#define __REACTOR_PROTOCOL_DECODER_H__

#include "buffer.h"
#include "protocol_encoder.h"

namespace reactor {

class ProtocolDecoder {
public:
  virtual bool initialized() = 0;

  virtual bool initialize(Buffer& buffer) = 0;

  virtual bool decode(Buffer& buffer, unsigned char* out, int& out_length) = 0;
};

}

#endif/*__REACTOR_PROTOCOL_DECODER_H__*/
