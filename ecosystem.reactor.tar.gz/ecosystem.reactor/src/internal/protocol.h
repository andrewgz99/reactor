#ifndef __REACTOR_PROTOCOL_H__
#define __REACTOR_PROTOCOL_H__

namespace reactor {

//websocket protocol.
#define PROT_ID_WS_PING  (0x0A)
#define PROT_ID_WS_PONG  (0x0A)
//websocket decode type.
#define PROT_ID_WS_CODEC_TYPE_CLIENT  (1)
#define PROT_ID_WS_CODEC_TYPE_SERVER  (2)

}

#endif/*__REACTOR_PROTOCOL_H__*/
