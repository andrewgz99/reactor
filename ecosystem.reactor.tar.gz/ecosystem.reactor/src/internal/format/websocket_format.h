#ifndef __REACTOR_WEBSOCKET_FORMAT_H__
#define __REACTOR_WEBSOCKET_FORMAT_H__

typedef struct WebsocketFrameHeader {
  unsigned char b0;
  unsigned char b1;

  unsigned int extended_payload_len : 64;
  unsigned int mask_key : 32;
} __attribute__((packed, aligned(1))) WebsocketFrameHeader;

#endif/*__REACTOR_WEBSOCKET_FORMAT_H__*/
