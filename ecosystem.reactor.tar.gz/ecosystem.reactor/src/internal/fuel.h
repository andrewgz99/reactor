#ifndef __REACTOR_FUEL_H__
#define __REACTOR_FUEL_H__

#include <string>

namespace reactor {

class EventListener;
class Buffer;

class Fuel {
public:
  Fuel();
  ~Fuel();

  void setSocket(const int sockfd) {
    socket_ = sockfd;
  }

  const int getSocket() {
    return socket_;
  }

  void setTimeoutInterval(const int timeout_interval) {
    timeout_interval_ = timeout_interval;
  }

  const int getTimeoutInterval() {
    return timeout_interval_;
  }

  void setLastDateline(const long last_dateline) {
    last_dateline_ = last_dateline;
  }

  const long getLastDateline() {
    return last_dateline_;
  }

  void setListener(EventListener* listener) {
    listener_ = listener;
  }

  EventListener* getListener() {
    return listener_;
  }

  void setWriteBuffer(Buffer* buffer) {
    write_buffer_ = buffer;
  }

  Buffer* getWriteBuffer() {
    return write_buffer_;
  }

  void setReadBuffer(Buffer* buffer) {
    read_buffer_ = buffer;
  }

  Buffer* getReadBuffer() {
    return read_buffer_;
  }

  void setType(const int type) {
    type_ = type;
  }

  const int getType() {
    return type_;
  }

  const bool getAcceptable() {
    return acceptable_;
  }

  void setAcceptable(const bool acceptable) {
    acceptable_ = acceptable;
  }
private:
  int socket_;

  int type_;

  int timeout_interval_;

  long last_dateline_;

  EventListener* listener_ = nullptr;

  Buffer* write_buffer_ = nullptr;

  Buffer* read_buffer_ = nullptr;

  bool acceptable_;
};

}

#endif/*__REACTOR_FUEL_H__*/
