#include "container.h"

#include <sys/socket.h>
#include <unistd.h>

#include <ctime>

#include "log4cpp.h"

#include "internal/common_utils.h"
#include "internal/fuel.h"
#include "internal/event.h"
#include "event_listener.h"

using namespace log4cpp;

namespace reactor {

void Container::handleEvent() {
  Event* event = nullptr;

  while (event = events_queue_.pop()) {
    //Log4cpp::getInstance().debug("reactor", "got event with id->%d", event->getId());

    switch (event->getId()) {
    case Event::EVENT_ID_ADD: {
      std::map<int, Fuel*>::iterator it = fuels_map_.find(event->getSocket());
      if (it == fuels_map_.end()) {
        Fuel* fuel = event->getFuel();

        FD_SET(fuel->getSocket(), &readfds_);

        Log4cpp::getInstance().debug("reactor", "new fuel added...");

        fuels_map_.insert(std::pair<int, Fuel*>(fuel->getSocket(), fuel));
        if (max_fd_ < fuel->getSocket()) {
          max_fd_ = fuel->getSocket();
        }

        fd_count_++;
      } else {
        Log4cpp::getInstance().debug("reactor", "fuel already exists...");
      }
    } break ;
    case Event::EVENT_ID_TIMEOUT: {
      if (fuels_map_.size() > 0) {
        std::map<int, Fuel*>::iterator it = fuels_map_.find(event->getSocket());
        if (it != fuels_map_.end()) {
          Fuel* fuel = it->second;
          fuel->setTimeoutInterval(event->getTimeoutInterval());
          Log4cpp::getInstance().debug("reactor", "fuel timeout setted, interval->%d",
          fuel->getTimeoutInterval());
        } else {
          Log4cpp::getInstance().debug("reactor", "not found fuel...");
        }
      } else {
        //Log4cpp::getInstance().error("reactor", "no fuel available..");
      }
    } break ;
    case Event::EVENT_ID_REMOVE: {
      if (fuels_map_.size() > 0) {
        std::map<int, Fuel*>::iterator it = fuels_map_.find(event->getSocket());
        if (it != fuels_map_.end()) {
          Fuel* fuel = it->second;

          FD_CLR(fuel->getSocket(), &readfds_);

          close(fuel->getSocket());

          delete fuel;
          fuel = nullptr;

          fuels_map_.erase(it);

          fd_count_--;

          Log4cpp::getInstance().debug("reactor", "fuel removed...");
        } else {
          Log4cpp::getInstance().debug("reactor", "not found fuel...");
        }
      } else {
      //  Log4cpp::getInstance().error("reactor", "no fuel available..");
      }
    } break ;
    case Event::EVENT_ID_SEND: {
      if (fuels_map_.size() > 0) {
        std::map<int, Fuel*>::iterator it = fuels_map_.find(event->getSocket());
        if (it != fuels_map_.end()) {
          Fuel* fuel = it->second;
          Buffer* buffer = fuel->getWriteBuffer();
          if (buffer->writtableBytes() > 0) {
            //write data to buffer.
            unsigned char* data = nullptr;
            int length = 0;
            if (!event->getData().empty()) {
              data = (unsigned char*)event->getData().c_str();
              length = event->getData().length();
            } else if (event->getData(data, length)) {

            }

            if (data && length > 0) {
              if (buffer->writtableBytes() >= length) {
                buffer->write(data, length);
                total_writting_bytes_ += length;

                //Log4cpp::getInstance().error("reactor",
                  //"total_writting_bytes_-->%d", total_writting_bytes_);

                FD_SET(fuel->getSocket(), &writefds_);

                //Log4cpp::getInstance().debug("reactor", "data written to send buffer...");
              } else {
                Log4cpp::getInstance().error("reactor", "send buffer is full...");

                fuel->getListener()
                  ->handleError(ERROR_ID_WRITE_BUFFER_FULL, data, length);
              }
            }
          } else {
            Log4cpp::getInstance().error("reactor", "not space to write..");
          }
        } else {
          Log4cpp::getInstance().error("reactor", "not found socket..");
        }
      } else {
      //  Log4cpp::getInstance().error("reactor", "no fuel available..");
      }
    } break ;
    default: {

    } break ;
    }

    delete event;
    event = nullptr;
  }

}

void Container::handleTimeout() {
  std::map<int, Fuel*>::iterator it = fuels_map_.begin();
  for (it; it != fuels_map_.end(); ++it) {
    Fuel* fuel = it->second;

    if (0 == fuel->getTimeoutInterval()) {
      //Log4cpp::getInstance().debug("reactor", "fuel timeout not enabled");

      continue ;
    }

    fuel->setLastDateline(fuel->getLastDateline() + 100);
    if (fuel->getLastDateline() < fuel->getTimeoutInterval()) {
    //  Log4cpp::getInstance().debug("reactor", "fuel timeout not reached");

      continue ;
    }

  //  Log4cpp::getInstance().debug("reactor", "fuel timeout happened");
    fuel->getListener()->handleTimeout(fuel->getSocket());
    fuel->setLastDateline(0);
  }
}

void Container::handleRead(Fuel* fuel) {
  Buffer* buffer = fuel->getReadBuffer();

  int socket = fuel->getSocket();

  if (buffer->writtableBytes() <= 0) {
    fuel->getListener()->handleInput(*buffer);

    return ;
  }

  unsigned char tmp_buf[1024];
  int length = sizeof(tmp_buf);
  if (length > buffer->writtableBytes()) {
    length = buffer->writtableBytes();
  }

  int result = -1;
  if (fuel->getAcceptable()) {
    fuel->getListener()->handleAccept(socket);

    return ;
  }

  if (CommonUtils::FUEL_TYPE_RAW == fuel->getType()) {
    result = ::recv(socket, tmp_buf, length, 0);
  } else {
    //handle input.
    result = fuel->getListener()->handleRead(tmp_buf, length);
  }

  if (result <= 0) {
    if (0 == result || errno != EWOULDBLOCK) {
      //remote close.
      Log4cpp::getInstance().debug("reactor", "remove close connection or other error.");

      fuel->getListener()->handleClose(socket);

      fuel->getListener()->handleError(ERROR_ID_CONNECTION_CLOSED);
    }

    return ;
  }

  result = buffer->write(tmp_buf, result);

  //handle input.
  fuel->getListener()->handleInput(*buffer);

}

void Container::handleWrite(Fuel* fuel) {
  Buffer* buffer = fuel->getWriteBuffer();

  int socket = fuel->getSocket();

  unsigned char tmp_buf[1024];

  int nread = 0;
  while ((nread = buffer->read(tmp_buf, sizeof(tmp_buf))) > 0) {
    int result = -1;

    int nleft = nread;
    int index = 0;
    do {
      if (CommonUtils::FUEL_TYPE_RAW == fuel->getType()) {
        result = ::send(socket, tmp_buf + index, nleft, 0);
        index += result;
      } else {
        result = fuel->getListener()->handleWrite(tmp_buf + index, nleft);
      }

      if (result > 0) {
        nleft -= result;
        index += result;
      } else if (result <= 0) {
        if (errno != EWOULDBLOCK) {
          total_writting_bytes_ -= nread;
          total_writting_bytes_ -= buffer->readableBytes();

          //Log4cpp::getInstance().error("reactor",
            //"total_writting_bytes_-->%d", total_writting_bytes_);

          //remove socket.
          Event* event = new Event();
          event->setId(Event::EVENT_ID_REMOVE);
          event->setSocket(socket);
          events_queue_.push(event);

          Log4cpp::getInstance().error("reactor", "send failed.socket error...");

          return ;
        }
      }
    } while (nleft > 0);

    total_writting_bytes_ -= nread;
  }
}

void Container::loop() {
  Log4cpp::getInstance().debug("reactor", "container is running...");

  while (running_ || total_writting_bytes_ > 0 || events_queue_.size() > 0) {
    handleEvent();

    if (fd_count_ <= 0) {
      usleep(1000 * 100);

      continue ;
    }

    fd_set readfds = readfds_;
    fd_set writefds = writefds_;
    fd_set* writtingfds = nullptr;

    if (total_writting_bytes_ > 0) {
      writtingfds = &writefds;
    }

    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 100;
    int result = select(max_fd_ + 1, &readfds, writtingfds, nullptr, &tv);
    if (result <= 0) {
      if (-1 == result) {
        Log4cpp::getInstance().error("reactor", "select failed...");
      }

      //Log4cpp::getInstance().debug("reactor", "select return %d...", result);
    } else {
      //Log4cpp::getInstance().debug("reactor", "select return %d...", result);
      //Log4cpp::getInstance().debug("reactor", "fuels count %d...", fuels_map_.size());
      std::map<int, Fuel*>::iterator it = fuels_map_.begin();
      for (it; it != fuels_map_.end(); ++it) {
        int socket = it->second->getSocket();
        if (FD_ISSET(socket, &readfds)) {
          handleRead(it->second);
        }

        if (writtingfds) {
          if (FD_ISSET(socket, writtingfds)) {
            handleWrite(it->second);
          }
        }

        if (CommonUtils::getCurrentDatelineInMilliseconds() - io_begin_time_ >= 100) {
          handleTimeout();

          io_begin_time_ = CommonUtils::getCurrentDatelineInMilliseconds();
        }
      }
    }

    if (CommonUtils::getCurrentDatelineInMilliseconds() - io_begin_time_ >= 100) {
      handleTimeout();

      io_begin_time_ = CommonUtils::getCurrentDatelineInMilliseconds();
    }
  }

  release();

  Log4cpp::getInstance().debug("reactor", "container quit...");
}

bool Container::add(Fuel* fuel) {
  bool ret_value = false;

  Event* event = new Event();
  event->setId(Event::EVENT_ID_ADD);
  event->setSocket(fuel->getSocket());
  event->setFuel(fuel);
  events_queue_.push(event);

  ret_value = true;

  return ret_value;
}

bool Container::send(const int sockfd, const std::string& data) {
  bool ret_value = false;

  Event* event = new Event();
  event->setId(Event::EVENT_ID_SEND);
  event->setSocket(sockfd);
  event->setData(data);
  events_queue_.push(event);
  ret_value = true;

  return ret_value;
}

bool Container::send(const int sockfd, const unsigned char* data, const int length) {
  bool ret_value = false;

  Event* event = new Event();
  event->setId(Event::EVENT_ID_SEND);
  event->setSocket(sockfd);
  event->setData(data, length);
  events_queue_.push(event);
  ret_value = true;

  return ret_value;
}

void Container::setTimeout(const int sockfd, const int milliseconds) {
  Event* event = new Event();
  event->setId(Event::EVENT_ID_TIMEOUT);
  event->setSocket(sockfd);
  event->setTimeoutInterval(milliseconds);
  events_queue_.push(event);
}

void Container::remove(const int sockfd) {
  Event* event = new Event();
  event->setId(Event::EVENT_ID_REMOVE);
  event->setSocket(sockfd);
  events_queue_.push(event);
}

bool Container::initialize() {
  bool ret_value = false;

  ret_value = true;

  return ret_value;
}

void Container::release() {

}

void Container::setRunning(const bool running) {
  running_ = running;
}

bool Container::isRunning() {
  return running_;
}

Container::Container() {
  running_ = false;

  fd_count_ = 0;
  max_fd_ = 0;

  FD_ZERO(&readfds_);
  FD_ZERO(&writefds_);

  total_writting_bytes_ = 0;

  io_begin_time_ = time(nullptr);
}

Container::~Container() {

}

}
