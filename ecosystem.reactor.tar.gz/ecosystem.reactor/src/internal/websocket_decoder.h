#ifndef __REACTOR_WEBSOCKET_DECODER_H__
#define __REACTOR_WEBSOCKET_DECODER_H__

#include <byteswap.h>

#include <openssl/sha.h>
#include <openssl/bio.h>
#include <openssl/evp.h>

#include "log4cpp.h"
#include "protocol_decoder.h"
#include "internal/protocol.h"

namespace reactor {

class WebsocketDecoder : public ProtocolDecoder {
public:
  WebsocketDecoder() {
    handsharked_ = false;
  }
  virtual ~WebsocketDecoder() {

  }

  virtual bool initialized() {
    return handsharked_;
  }

  virtual bool initialize(Buffer& buffer) {
    bool ret_value = false;

    if (PROT_ID_WS_CODEC_TYPE_CLIENT == type_) {
      const int nreceived = buffer.readableBytes();
      char buff[nreceived + 1];
      int result = buffer.copy((unsigned char*)buff, nreceived);
      if (result <= 0) {
        return ret_value;
      }

      char* end = strstr(buff, "\r\n\r\n");
      if (end) {
        int nread = end - buff + 4;
        buffer.read((unsigned char*)buff, nread);

        handsharked_ = true;
        ret_value = true;

        log4cpp::Log4cpp::getInstance().debug("reactor", "server responds->\r\n%s",
          buff);
      }
    } else if (PROT_ID_WS_CODEC_TYPE_SERVER == type_) {
      const int nreceived = buffer.readableBytes();
      char buff[nreceived + 1];
      int result = buffer.copy((unsigned char*)buff, nreceived);
      if (result <= 0) {
        return ret_value;
      }

      char* end = strstr(buff, "\r\n\r\n");
      if (end) {
        int nread = end - buff + 4;
        buffer.read((unsigned char*)buff, nread);

        //parse request.
        std::string request(buff, nread);
        const char* key = "Sec-WebSocket-Key:";
        const char* key_begin = strstr(request.c_str(), key);
        if (key_begin) {
          key_begin += strlen(key);
          const char* key_end = strstr(key_begin, "\r\n");
          if (key_end) {
            while (' ' == *key_begin) {
              key_begin++;
            }
            int key_length = key_end - key_begin;
            std::string request_key = std::string(key_begin, key_length);

            log4cpp::Log4cpp::getInstance().debug("reactor", "request_key->%s",
              request_key.c_str());

            request_key_ = request_key;
          }
        }

        handsharked_ = true;

        //generate response.
        log4cpp::Log4cpp::getInstance().debug("reactor", "request->%s",
          request.c_str());

        ret_value = true;
      }
    }

    return ret_value;
  }

  virtual bool decode(Buffer& buffer, unsigned char* out, int& out_length) {
    bool ret_value = false;

    if (PROT_ID_WS_CODEC_TYPE_CLIENT == getType()) {

      const int nreceived = buffer.readableBytes();
      if (nreceived < 2) {
        ret_value = true;

        return ret_value;
      }

      char buff[2];
      int result = buffer.copy((unsigned char*)buff, sizeof(buff));
      if (2 != result) {
        log4cpp::Log4cpp::getInstance().debug("reactor", "copy return->%d", result);

        return ret_value;
      }

      unsigned char opcode = buff[0] & 0x0F;
      int payload_len = buff[1] & 0x7F;
      unsigned char mask = buff[1] & 0x80;
      unsigned long long extended_payload_len = 0;
      unsigned int mask_key = 0;

      if (payload_len > out_length) {
        return ret_value;
      }
      if (payload_len > nreceived) {
        return ret_value;
      }

      if (0x01 == opcode || 0x02 == opcode) {
        buffer.read(out, 2);
        if (payload_len >= 0 && payload_len <= 125) {
          if (mask) {
            buffer.read((unsigned char*)&mask_key, sizeof(mask_key));
          }
        } else if (payload_len > 125 && payload_len < 1 << 16) {
          buffer.read((unsigned char*)&extended_payload_len, 2);
          extended_payload_len = ntohs(extended_payload_len);

          if (mask) {
            buffer.read((unsigned char*)&mask_key, sizeof(mask_key));
          }
        } else if (payload_len >= 1 << 16 && payload_len < 1 << 64) {
          buffer.read(
            (unsigned char*)&extended_payload_len,
            sizeof(extended_payload_len));
          extended_payload_len = bswap_64(extended_payload_len);
          if (mask) {
            buffer.read((unsigned char*)&mask_key, sizeof(mask_key));
          }
        } else {
          log4cpp::Log4cpp::getInstance().debug("reactor", "payload_len->%d",
            payload_len);

          return ret_value;
        }
        if (0 == extended_payload_len) {
          extended_payload_len = payload_len;
        }
        buffer.read(out, extended_payload_len);
        //unsigned int mask_key = 0x0a0b0c0d;
        int index = 0;
        for (int i = 0; i < extended_payload_len; ++i) {
          unsigned char mask_byte = (((unsigned char*)&mask_key))[i % 4];

          (out + index)[i] = (out + index)[i] ^ mask_byte;
        }

        out_length = extended_payload_len;
        mask_key_ = mask_key;
      }

      if (0x8 == opcode) {
        log4cpp::Log4cpp::getInstance().debug("reactor", "remote close connection");
      } else {
        ret_value = true;
      }
    } else if (PROT_ID_WS_CODEC_TYPE_SERVER == getType()) {
      const int nreceived = buffer.readableBytes();
      if (nreceived < 2) {
        ret_value = true;

        return ret_value;
      }

      char buff[2];
      int result = buffer.copy((unsigned char*)buff, sizeof(buff));
      if (2 != result) {
        log4cpp::Log4cpp::getInstance().debug("reactor", "copy return->%d", result);

        return ret_value;
      }

      unsigned char opcode = buff[0] & 0x0F;
      int payload_len = buff[1] & 0x7F;
      unsigned char mask = buff[1] & 0x80;
      unsigned long long extended_payload_len = 0;
      unsigned int mask_key = 0;

      if (payload_len > out_length) {
        return ret_value;
      }

      if (0x01 == opcode || 0x02 == opcode) {
        buffer.read(out, 2);
        if (payload_len >= 0 && payload_len <= 125) {
          if (mask) {
            buffer.read((unsigned char*)&mask_key, sizeof(mask_key));
          }
        } else if (payload_len > 125 && payload_len < 1 << 16) {
          buffer.read((unsigned char*)&extended_payload_len, 2);
          extended_payload_len = ntohs(extended_payload_len);
          if (mask) {
            buffer.read((unsigned char*)&mask_key, sizeof(mask_key));
          }
        } else if (payload_len >= 1 << 16 && payload_len < 1 << 64) {
          buffer.read((unsigned char*)&extended_payload_len, sizeof(extended_payload_len));
          extended_payload_len = bswap_64(extended_payload_len);
          if (mask) {
            buffer.read((unsigned char*)&mask_key, sizeof(mask_key));
          }
        } else {
          log4cpp::Log4cpp::getInstance().debug("reactor", "payload_len->%d",
            payload_len);

          return ret_value;
        }
        if (0 == extended_payload_len) {
          extended_payload_len = payload_len;
        }
        buffer.read(out, extended_payload_len);
        //unsigned int mask_key = 0x0a0b0c0d;
        int index = 0;
        for (int i = 0; i < payload_len; ++i) {
          unsigned char mask_byte = (((unsigned char*)&mask_key))[i % 4];

          (out + index)[i] = (out + index)[i] ^ mask_byte;
        }

        out_length = extended_payload_len;
        mask_key_ = mask_key;
      }

      if (0x8 == opcode) {
        log4cpp::Log4cpp::getInstance().debug("reactor", "remote close connection");
      } else {
        ret_value = true;
      }
    }

    return ret_value;
  }

  void setType(const int type) {
    type_ = type;
  }

  const int getType() {
    return type_;
  }

  const unsigned int getMaskKey() {
    return mask_key_;
  }

  const std::string& getAcceptKey() {
    std::string key = request_key_ + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

    unsigned char obuf[20];
    SHA1((const unsigned char*)key.c_str(), key.length(), obuf);

    BIO *base64_filter = BIO_new( BIO_f_base64() );
    BIO_set_flags( base64_filter, BIO_FLAGS_BASE64_NO_NL );
    BIO *bio = BIO_new( BIO_s_mem() );
    BIO_set_flags( bio, BIO_FLAGS_BASE64_NO_NL );
    bio = BIO_push( base64_filter, bio );
    BIO_write( bio, obuf, sizeof(obuf) );
    BIO_flush( bio );
    char *new_data;
    long bytes_written = BIO_get_mem_data( bio, &new_data );

    std::string result( new_data, bytes_written );
    BIO_free_all( bio );

    accept_key_ = result;

    return accept_key_;
  }

private:
  bool handsharked_;

  int type_;//1 client, 2 server.

  unsigned int mask_key_;

  std::string request_key_;

  std::string accept_key_;
};

}

#endif/*__REACTOR_WEBSOCKET_DECODER_H__*/
