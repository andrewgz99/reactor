#ifndef __REACTOR_EPOLL_CONTAINER_H__
#define __REACTOR_EPOLL_CONTAINER_H__

#if defined(__linux__)
/* According to POSIX.1-2001 */
#include <sys/select.h>
/* According to earlier standards */
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#elif defined(WIN32)

#endif

#include "base_container.h"

namespace reactor {

class EPollContainer : public BaseContainer {
public:
  EPollContainer();
  ~EPollContainer();

  virtual bool add(Fuel* fuel);

  virtual void setTimeout(const int sockfd, const int milliseconds);

  virtual bool send(const int sockfd, const std::string& data);

  virtual bool send(const int sockfd, const unsigned char* data, const int length);

  virtual void remove(const int sockfd);

  virtual bool initialize();

  virtual void release();

  virtual void setRunning(const bool running);

  virtual bool isRunning();

  virtual void loop();
private:
  void handleEvent();

  void handleTimeout();

  void handleRead(Fuel* fuel);

  void handleWrite(Fuel* fuel);

  bool running_;

  ConcurrentQueue<Event*> events_queue_;

  long total_writting_bytes_;

  std::map<int, Fuel*> fuels_map_;

  long io_begin_time_;

  int epollfd_;
};

}

#endif/*__REACTOR_EPOLL_CONTAINER_H__*/
