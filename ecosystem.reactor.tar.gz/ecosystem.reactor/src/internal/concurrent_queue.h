#ifndef __REACTOR_CONCURRENT_QUEUE_H__
#define __REACTOR_CONCURRENT_QUEUE_H__

#include <atomic>

namespace reactor {

template <typename T>
class ConcurrentQueue {
public:
  struct Node {
    T data;
    Node* next;
    Node() : next(nullptr) {

    }
  };

  ConcurrentQueue() : head_(new Node()), tail_(head_.load()) {
    count_ = 0;
  }

  ~ConcurrentQueue() {

  }

  T pop() {
    T ret_value = nullptr;
    Node* old_head = popHead();
    if (!old_head) {
      return nullptr;
    }

    ret_value = old_head->data;
    delete old_head;
    old_head = nullptr;

    count_--;

    return ret_value;
  }

  void push(T new_value) {
    Node* new_node = new Node;

    Node* const old_tail = tail_.load();
    old_tail->data = new_value;
    old_tail->next = new_node;
    tail_.store(new_node);
    count_++;
  }

  int size() {
    return count_;
  }

private:
  ConcurrentQueue(const ConcurrentQueue& other) = delete;
  const ConcurrentQueue& operator=(const ConcurrentQueue& other) = delete;

  Node* popHead() {
    Node* const old_head = head_.load();
    if (old_head == tail_.load()) {
      return nullptr;
    }
    head_.store(old_head->next);
    return old_head;
  }

  std::atomic<Node*> head_;
  std::atomic<Node*> tail_;

  std::atomic<int> count_;
};

}

#endif/*__REACTOR_CONCURRENT_QUEUE_H__*/
