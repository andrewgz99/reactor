#ifndef __REACTOR_BASE_CONTAINER_H__
#define __REACTOR_BASE_CONTAINER_H__

#include <string>
#include <map>

#include "concurrent_queue.h"
#include "event.h"
#include "fuel.h"

namespace reactor {

class BaseContainer {
public:
  virtual bool add(Fuel* fuel) { return false; }

  virtual void setTimeout(const int sockfd, const int milliseconds) {}

  virtual bool send(const int sockfd, const std::string& data) { return false; }

  virtual bool send(const int sockfd, const unsigned char* data, const int length) { return false; }

  virtual void remove(const int sockfd) {}

  virtual bool initialize() { return false; }

  virtual void release() {}

  virtual void setRunning(const bool running) {}

  virtual bool isRunning() { return false; }

  virtual void loop() {}

};

}

#endif/*__REACTOR_BASE_CONTAINER_H__*/
