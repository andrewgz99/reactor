#include "epoll_container.h"

#include <sys/epoll.h>
#include <sys/socket.h>
#include <unistd.h>

#include <ctime>

#include "log4cpp.h"

#include "internal/common_utils.h"
#include "event_listener.h"

using namespace log4cpp;

namespace reactor {

EPollContainer::EPollContainer() {
  running_ = false;

  total_writting_bytes_ = 0;

  io_begin_time_ = time(nullptr);

  epollfd_ = epoll_create1(0);
}

EPollContainer::~EPollContainer() {
  if (epollfd_ > 0) {
    if(close(epollfd_) <= 0) {
      Log4cpp::getInstance().error("reactor", "close epoll fd failed");
    }

    epollfd_ = -1;
  }
}

bool EPollContainer::add(Fuel* fuel) {
  bool ret_value = false;

  Event* event = new Event();
  event->setId(Event::EVENT_ID_ADD);
  event->setSocket(fuel->getSocket());
  event->setFuel(fuel);
  events_queue_.push(event);

  ret_value = true;

  return ret_value;
}

void EPollContainer::remove(const int sockfd) {
  Event* event = new Event();
  event->setId(Event::EVENT_ID_REMOVE);
  event->setSocket(sockfd);
  events_queue_.push(event);
}

void EPollContainer::setTimeout(const int sockfd, const int milliseconds) {
  Event* event = new Event();
  event->setId(Event::EVENT_ID_TIMEOUT);
  event->setSocket(sockfd);
  event->setTimeoutInterval(milliseconds);
  events_queue_.push(event);
}

bool EPollContainer::send(const int sockfd, const std::string& data) {
  bool ret_value = false;

  Event* event = new Event();
  event->setId(Event::EVENT_ID_SEND);
  event->setSocket(sockfd);
  event->setData(data);
  events_queue_.push(event);
  ret_value = true;

  return ret_value;
}

bool EPollContainer::send(
    const int sockfd, const unsigned char* data, const int length) {
  bool ret_value = false;

  Event* event = new Event();
  event->setId(Event::EVENT_ID_SEND);
  event->setSocket(sockfd);
  event->setData(data, length);
  events_queue_.push(event);
  ret_value = true;

  return ret_value;
}

bool EPollContainer::initialize() {
  bool ret_value = false;

  ret_value = true;

  return ret_value;
}

void EPollContainer::release() {

}

void EPollContainer::setRunning(const bool running) {
  running_ = running;
}

bool EPollContainer::isRunning() {
  return running_;
}

void EPollContainer::loop() {
  Log4cpp::getInstance().debug("reactor", "container is running...");

  while (running_ || total_writting_bytes_ > 0 || events_queue_.size() > 0) {
    handleEvent();

    if (fuels_map_.size() <= 0) {
      usleep(1000 * 100);

      continue ;
    }

    struct epoll_event events[126];
    int result = epoll_wait(
      epollfd_, events, sizeof(events) / sizeof(events[0]), 100);
    if (result <= 0) {
      continue ;
    }

    for (int i = 0; i < result; ++i) {
      Fuel* fuel = (Fuel*)events[i].data.ptr;

      if (events[i].events & EPOLLIN) {
        handleRead(fuel);
      } else if (events[i].events & EPOLLOUT) {
        handleWrite(fuel);
      } else if (events[i].events & EPOLLHUP) {
        Log4cpp::getInstance().error("reactor",
          "socket error->%d", fuel->getSocket());

        remove(fuel->getSocket());
        fuel->getListener()->handleError(ERROR_ID_CONNECTION_CLOSED);
      } else if (events[i].events & EPOLLERR) {
        Log4cpp::getInstance().error("reactor",
          "socket error->%d", fuel->getSocket());

        remove(fuel->getSocket());
        fuel->getListener()->handleError(ERROR_ID_CONNECTION_CLOSED);
      }

      if (CommonUtils::getCurrentDatelineInMilliseconds() - io_begin_time_ >= 100) {
        handleTimeout();

        io_begin_time_ = CommonUtils::getCurrentDatelineInMilliseconds();
      }
    }

    if (CommonUtils::getCurrentDatelineInMilliseconds() - io_begin_time_ >= 100) {
      handleTimeout();

      io_begin_time_ = CommonUtils::getCurrentDatelineInMilliseconds();
    }
  }

  release();

  Log4cpp::getInstance().debug("reactor", "container quit...");
}

void EPollContainer::handleEvent() {
  Event* event = nullptr;

  while (event = events_queue_.pop()) {
    Log4cpp::getInstance().debug("reactor", "got event with id->%d", event->getId());

    switch (event->getId()) {
    case Event::EVENT_ID_ADD: {
      std::map<int, Fuel*>::iterator it = fuels_map_.find(event->getSocket());
      if (it == fuels_map_.end()) {
        struct epoll_event ev;

        ev.events = EPOLLIN;
        ev.data.fd = event->getFuel()->getSocket();
        ev.data.ptr = event->getFuel();

        if(epoll_ctl(
          epollfd_, EPOLL_CTL_ADD, event->getFuel()->getSocket(), &ev) < 0) {
          Log4cpp::getInstance().error("reactor", "add fd failed");
        } else {
          fuels_map_.insert(
            std::pair<int, Fuel*>(
              event->getFuel()->getSocket(), event->getFuel()));
          Log4cpp::getInstance().debug("reactor", "add fd ok. socket->%d",
            event->getFuel()->getSocket()
        );
        }
      }
    } break ;
    case Event::EVENT_ID_REMOVE: {
      if (fuels_map_.size() > 0) {
        std::map<int, Fuel*>::iterator it = fuels_map_.find(event->getSocket());
        if (it != fuels_map_.end()) {
          Fuel* fuel = it->second;

          struct epoll_event ev;

          ev.events = EPOLLIN | EPOLLOUT;
          ev.data.fd = event->getSocket();

          if(epoll_ctl(
            epollfd_, EPOLL_CTL_DEL, event->getSocket(), &ev) < 0) {
            Log4cpp::getInstance().error("reactor", "remove fd failed");
          } else {
            close(fuel->getSocket());

            fuels_map_.erase(it);

            Log4cpp::getInstance().debug("reactor", "fuel removed...");
          }

          delete fuel;
          fuel = nullptr;
        }
      }
    } break ;
    case Event::EVENT_ID_TIMEOUT: {
      if (fuels_map_.size() > 0) {
        std::map<int, Fuel*>::iterator it = fuels_map_.find(event->getSocket());
        if (it != fuels_map_.end()) {
          Fuel* fuel = it->second;
          fuel->setTimeoutInterval(event->getTimeoutInterval());
          Log4cpp::getInstance().debug("reactor", "fuel timeout setted, interval->%d",
          fuel->getTimeoutInterval());
        } else {
          Log4cpp::getInstance().debug("reactor", "not found fuel...");
        }
      } else {
        Log4cpp::getInstance().error("reactor", "no fuel available..");
      }
    } break ;
    case Event::EVENT_ID_SEND: {
      if (fuels_map_.size() > 0) {
        std::map<int, Fuel*>::iterator it =
          fuels_map_.find(event->getSocket());
        if (it != fuels_map_.end()) {
          Fuel* fuel = it->second;
          Buffer* buffer = fuel->getWriteBuffer();
          if (buffer->writtableBytes() > 0) {
            //write data to buffer.
            unsigned char* data = nullptr;
            int length = 0;
            if (!event->getData().empty()) {
              data = (unsigned char*)event->getData().c_str();
              length = event->getData().length();
            } else if (event->getData(data, length)) {

            }

            if (data && length > 0) {
              if (buffer->writtableBytes() >= length) {
                buffer->write(data, length);
                total_writting_bytes_ += length;

                //Log4cpp::getInstance().error("reactor",
                  //"total_writting_bytes_-->%d", total_writting_bytes_);

                  struct epoll_event ev;

                  ev.events = EPOLLIN | EPOLLOUT;
                  ev.data.fd = event->getSocket();
                  ev.data.ptr = fuel;

                  if(epoll_ctl(
                    epollfd_, EPOLL_CTL_MOD, event->getSocket(), &ev) < 0) {
                    Log4cpp::getInstance().error("reactor", "change event for write failed");
                  } else {
                    Log4cpp::getInstance().debug("reactor", "fuel changed...");
                  }
                //Log4cpp::getInstance().debug("reactor", "data written to send buffer...");
              } else {
                Log4cpp::getInstance().error("reactor", "send buffer is full...");

                fuel->getListener()
                  ->handleError(ERROR_ID_WRITE_BUFFER_FULL, data, length);
              }
            }
          } else {
            Log4cpp::getInstance().error("reactor", "not space to write..");
          }
        } else {
          Log4cpp::getInstance().error("reactor", "not found socket..");
        }
      } else {
      //  Log4cpp::getInstance().error("reactor", "no fuel available..");
      }
    } break ;
    default: {

    } break ;
    }

    delete event;
    event = nullptr;
  }
}

void EPollContainer::handleTimeout() {
  std::map<int, Fuel*>::iterator it = fuels_map_.begin();
  for (it; it != fuels_map_.end(); ++it) {
    Fuel* fuel = it->second;

    if (0 == fuel->getTimeoutInterval()) {
      //Log4cpp::getInstance().debug("reactor", "fuel timeout not enabled");

      continue ;
    }

    fuel->setLastDateline(fuel->getLastDateline() + 100);
    if (fuel->getLastDateline() < fuel->getTimeoutInterval()) {
    //  Log4cpp::getInstance().debug("reactor", "fuel timeout not reached");

      continue ;
    }

  //  Log4cpp::getInstance().debug("reactor", "fuel timeout happened");
    fuel->getListener()->handleTimeout(fuel->getSocket());
    fuel->setLastDateline(0);

    fuels_map_.erase(it);
  }
}

void EPollContainer::handleRead(Fuel* fuel) {
  Buffer* buffer = fuel->getReadBuffer();

  int socket = fuel->getSocket();

  if (buffer->writtableBytes() <= 0) {
    fuel->getListener()->handleInput(*buffer);

    return ;
  }

  unsigned char tmp_buf[1024];
  int length = sizeof(tmp_buf);
  if (length > buffer->writtableBytes()) {
    length = buffer->writtableBytes();
  }

  int result = -1;
  if (fuel->getAcceptable()) {
    fuel->getListener()->handleAccept(socket);

    return ;
  }

  if (CommonUtils::FUEL_TYPE_RAW == fuel->getType()) {
    result = ::recv(socket, tmp_buf, length, 0);
  } else {
    //handle input.
    result = fuel->getListener()->handleRead(tmp_buf, length);
  }

  if (result <= 0) {
    if (0 == result || errno != EWOULDBLOCK) {
      //remote close.
      Log4cpp::getInstance().debug("reactor", "remove close connection or other error.");
      remove(fuel->getSocket());

      fuel->getListener()->handleClose(socket);

      fuel->getListener()->handleError(ERROR_ID_CONNECTION_CLOSED);
    }

    return ;
  }

  result = buffer->write(tmp_buf, result);

  //handle input.
  fuel->getListener()->handleInput(*buffer);
}

void EPollContainer::handleWrite(Fuel* fuel) {
  Log4cpp::getInstance().error("reactor", "start to write data...");

  Buffer* buffer = fuel->getWriteBuffer();

  int socket = fuel->getSocket();

  unsigned char tmp_buf[1024];

  int nread = 0;
  while ((nread = buffer->read(tmp_buf, sizeof(tmp_buf))) > 0) {
    int result = -1;

    int nleft = nread;
    int index = 0;
    do {
      if (CommonUtils::FUEL_TYPE_RAW == fuel->getType()) {
        result = ::send(socket, tmp_buf + index, nleft, 0);

        Log4cpp::getInstance().debug("reactor",
        "direct write...result->%d", result);
      } else {
        Log4cpp::getInstance().debug("reactor", "handle write...");
        result = fuel->getListener()->handleWrite(tmp_buf + index, nleft);
      }

      if (result > 0) {
        nleft -= result;
        index += result;
      } else if (result <= 0) {
        if (errno != EWOULDBLOCK) {
          total_writting_bytes_ -= nread;
          total_writting_bytes_ -= buffer->readableBytes();

          //Log4cpp::getInstance().error("reactor",
            //"total_writting_bytes_-->%d", total_writting_bytes_);

          //remove socket.
          Event* event = new Event();
          event->setId(Event::EVENT_ID_REMOVE);
          event->setSocket(socket);
          events_queue_.push(event);

          Log4cpp::getInstance().error("reactor", "send failed.socket error...");

          return ;
        }
      }
    } while (nleft > 0);

    total_writting_bytes_ -= nread;
  }

  //remove.
  struct epoll_event ev;

  ev.events = EPOLLIN;
  ev.data.fd = socket;
  ev.data.ptr = fuel;

  if(epoll_ctl(
    epollfd_, EPOLL_CTL_MOD, socket, &ev) < 0) {
    Log4cpp::getInstance().error("reactor", "change event for write failed");
  } else {
    Log4cpp::getInstance().debug("reactor", "fuel changed...");
  }
}

}
