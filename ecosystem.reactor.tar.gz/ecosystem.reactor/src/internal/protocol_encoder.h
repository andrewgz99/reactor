#ifndef __REACTOR_PROTOCOL_ENCODER_H__
#define __REACTOR_PROTOCOL_ENCODER_H__

#include <string>

namespace reactor {

class ProtocolEncoder {
public:
  virtual bool encode(const std::string& data,
              const int mask_key,
              unsigned char* out, int& out_length) {}

  virtual bool encode(const std::string& data,
              unsigned char* out, int& out_length) = 0;

  virtual bool encode(const unsigned char* data, const int length,
              unsigned char* out, int& out_length) = 0;

  void setType(const int type) {
    type_ = type;
  }

  const int getType() {
    return type_;
  }
private:
  int type_;
};

}

#endif/*__REACTOR_PROTOCOL_ENCODER_H__*/
