#ifndef __REACTOR_COMMON_UTILS_H__
#define __REACTOR_COMMON_UTILS_H__

#include <sys/time.h>

namespace reactor {

class CommonUtils {
public:
  static const int FUEL_TYPE_RAW = 1;
  static const int FUEL_TYPE_MANAGED = 2;

  static long long getCurrentDatelineInMilliseconds() {
      struct timeval te;
      gettimeofday(&te, NULL);
      long long milliseconds = te.tv_sec*1000LL + te.tv_usec/1000;

      return milliseconds;
  }
};

}

#endif/*__REACTOR_COMMON_UTILS_H__*/
