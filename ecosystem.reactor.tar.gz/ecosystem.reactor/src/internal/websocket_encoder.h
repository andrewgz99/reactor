#ifndef __REACTOR_WEBSOCKET_ENCODER_H__
#define __REACTOR_WEBSOCKET_ENCODER_H__

#include <byteswap.h>

#include "log4cpp.h"
#include "protocol_encoder.h"
#include "format/websocket_format.h"

namespace reactor {

class WebsocketEncoder : public ProtocolEncoder {
public:
  virtual bool encode(const std::string& data,
              const int mask_key, const int mask,
              unsigned char* out, int& out_length) {
    bool ret_value = false;

    unsigned long length = data.length() + 1;

    WebsocketFrameHeader header;
    memset(&header, 0x00, sizeof(header));
    header.b0 |= 0x00;//fin
    header.b0 |= 0x40;//rsv3
    header.b0 |= 0x20;//rsv2
    header.b0 |= 0x10;//rsv1
    header.b0 |= (0x1 & 0x0F);//opcode text frame

    header.b1 |= 0x00;//mask

    //payload length
    if (length >= 0 && length <= 125) {
      header.b1 |= length;
    } else if (length > 125 && length < 1 << 16) {
      header.b1 |= 126;
      header.extended_payload_len = htons(length);
    } else if (length >= 1 << 16 && length < 1 << 64) {
      header.b1 |= 127;
      header.extended_payload_len = bswap_64(length);
    } else {
      return ret_value;
    }
    //mask key.
    header.mask_key = mask_key;

    ret_value = doEncodeServer(header,
      (const unsigned char*)data.c_str(), data.length() + 1, out, out_length);

    return ret_value;
  }

  virtual bool encode(const std::string& data,
              const int mask_key,
              unsigned char* out, int& out_length) {
    bool ret_value = false;

    unsigned long length = data.length() + 1;

    WebsocketFrameHeader header;
    memset(&header, 0x00, sizeof(header));
    header.b0 |= 0x80;//fin
    header.b0 |= 0x40;//rsv3
    header.b0 |= 0x20;//rsv2
    header.b0 |= 0x10;//rsv1
    header.b0 |= (0x1 & 0x0F);//opcode text frame

    //payload length
    if (length >= 0 && length <= 125) {
      header.b1 |= length;
    } else if (length > 125 && length < 1 << 16) {
      header.b1 |= 126;
      header.extended_payload_len = htons(length);
    } else if (length >= 1 << 16 && length < 1 << 64) {
      header.b1 |= 127;
      header.extended_payload_len = bswap_64(length);
    } else {
      return ret_value;
    }
    //mask key.
    header.mask_key = mask_key;

    ret_value = doEncode(header,
      (const unsigned char*)data.c_str(), data.length() + 1, out, out_length);

    return ret_value;
  }

  virtual bool encode(const std::string& data,
              unsigned char* out, int& out_length) {
    bool ret_value = false;

    unsigned long length = data.length() + 1;

    WebsocketFrameHeader header;
    memset(&header, 0x00, sizeof(header));
    header.b0 |= 0x80;//fin
    header.b0 |= 0x00;//rsv3
    header.b0 |= 0x00;//rsv2
    header.b0 |= 0x00;//rsv1
    header.b0 |= (0x1 & 0x0F);//opcode text frame

    header.b1 |= 0x80;//mask
    //payload length
    if (length >= 0 && length <= 125) {
      header.b1 |= length;
    } else if (length > 125 && length < 1 << 16) {
      header.b1 |= 126;
      header.extended_payload_len = htons(length);
    } else if (length >= 1 << 16 && length < 1 << 64) {
      header.b1 |= 127;
      header.extended_payload_len = bswap_64(length);
    } else {
      return ret_value;
    }
    //mask key.
    header.mask_key = 0x0a0b0c0d;

    ret_value = doEncode(header,
      (const unsigned char*)data.c_str(), data.length() + 1, out, out_length);

    return ret_value;
  }

  virtual bool encode(const unsigned char* data, const int length,
              unsigned char* out, int& out_length) {
    bool ret_value = false;


    return ret_value;
  }

  virtual bool encodeServer(
              const int mask_key,
              const std::string& data,
              unsigned char* out, int& out_length) {
    bool ret_value = false;

    unsigned long length = data.length();

    WebsocketFrameHeader header;
    memset(&header, 0x00, sizeof(header));
    header.b0 |= 0x80;//fin
    header.b0 |= 0x00;//rsv3
    header.b0 |= 0x00;//rsv2
    header.b0 |= 0x00;//rsv1
    header.b0 |= (0x1 & 0x0F);//opcode text frame

    header.b1 |= 0x00;//mask
    //payload length
    if (length >= 0 && length <= 125) {
      header.b1 |= length;
    } else if (length > 125 && length < 1 << 16) {
      header.b1 |= 126;
      header.extended_payload_len = htons(length);
    } else if (length >= 1 << 16 && length < 1 << 64) {
      header.b1 |= 127;
      header.extended_payload_len = bswap_64(length);
    } else {
      return ret_value;
    }
    //mask key.
    header.mask_key = mask_key;

    ret_value = doEncodeServer(header,
      (const unsigned char*)data.c_str(), data.length(), out, out_length);

    log4cpp::Log4cpp::getInstance()
      .debug("reactor", "out_length->%d, mask_key->%u",
        out_length, mask_key);

    return ret_value;
  }

private:
  bool doEncodeServer(const WebsocketFrameHeader& header,
              const unsigned char* data, const int length,
              unsigned char* out, int& out_length) {
    bool ret_value = false;

    unsigned int index = 0;
    unsigned int source_index = 0;

    memcpy(out + index, ((unsigned char*)&header) + source_index, 2);
    index += 2;
    source_index += 2;

    int payload_len = header.b1 & 0x7F;
    if (126 == payload_len) {
      memcpy(out + index, ((unsigned char*)&header) + source_index, 2);
      index += 2;
      source_index += 2;
    } else if (127 == payload_len) {
      memcpy(out + index, ((unsigned char*)&header) + source_index, 8);
      index += 8;
      source_index += 8;
    }

/*
    //mask payload data.
    unsigned int mask_key = header.mask_key;

    memcpy(out + index, &mask_key, sizeof(mask_key));
    index += sizeof(mask_key);
    source_index += sizeof(mask_key);
*/

    memcpy(out + index, data, length);
    /*
    for (int i = 0; i < length; ++i) {
      unsigned char mask_byte = (((unsigned char*)&mask_key))[i % 4];

      (out + index)[i] = (out + index)[i] ^ mask_byte;
    }
    */
    index += length;

    out_length = index;

    ret_value = true;

    return ret_value;
  }

  bool doEncode(const WebsocketFrameHeader& header,
              const unsigned char* data, const int length,
              unsigned char* out, int& out_length) {
    bool ret_value = false;

    unsigned int index = 0;
    unsigned int source_index = 0;

    memcpy(out + index, ((unsigned char*)&header) + source_index, 2);
    index += 2;
    source_index += 2;

    int payload_len = header.b1 & 0x7F;
    if (126 == payload_len) {
      memcpy(out + index, ((unsigned char*)&header) + source_index, 2);
      index += 2;
      source_index += 2;
    } else if (127 == payload_len) {
      memcpy(out + index, ((unsigned char*)&header) + source_index, 8);
      index += 8;
      source_index += 8;
    }

    if (header.b1 & 0x80) {
      memcpy(out + index, ((unsigned char*)&header) + 10, 4);
      index += 4;
      source_index += 4;
    }

    memcpy(out + index, data, length);

    //mask payload data.
    unsigned int mask_key = header.mask_key;
    for (int i = 0; i < length; ++i) {
      unsigned char mask_byte = (((unsigned char*)&mask_key))[i % 4];

      (out + index)[i] = (out + index)[i] ^ mask_byte;
    }
    index += length;

    out_length = index;

    ret_value = true;

    return ret_value;
  }
};

}

#endif/*__REACTOR_PROTOCOL_ENCODER_H__*/
