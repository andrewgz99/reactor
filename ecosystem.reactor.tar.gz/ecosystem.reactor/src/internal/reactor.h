#ifndef __REACTOR_REACTOR_H__
#define __REACTOR_REACTOR_H__

#include "fuel.h"

namespace reactor {

class Reactor {
public:
  virtual ~Reactor() {}

  virtual bool start() = 0;

  virtual bool add(Fuel* fuel) = 0;

  virtual void setTimeout(const int sockfd, const int milliseconds) = 0;

  virtual bool send(const int sockfd, const std::string& data) = 0;

  virtual bool send(const int sockfd, const unsigned char* data, const int length) = 0;

  virtual void remove(const int sockfd) = 0;

  virtual void stop() = 0;
};

}

#endif/*__REACTOR_REACTOR_H__*/
