#include "internal/fuel.h"

namespace reactor {

Fuel::Fuel() {
  socket_ = 0;
  timeout_interval_ = 0;
  last_dateline_ = 0;
  acceptable_ = false;
}

Fuel::~Fuel() {
  if (write_buffer_) {
    delete write_buffer_;
    write_buffer_ = nullptr;
  }

  if (read_buffer_) {
    delete read_buffer_;
    read_buffer_ = nullptr;
  }
}

}
