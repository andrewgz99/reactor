#include "tcp_server.h"

#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>

#include "log4cpp.h"

#include "internal/fuel.h"
#include "impl/simple_buffer.h"
#include "internal/common_utils.h"

#include "internal/reactor_factory.h"
#include "initializer.h"

using namespace log4cpp;

namespace reactor {

TCPServer::TCPServer(const int size) {
  if (!isInitialized()) {
    return ;
  }

  reactor_ = ReactorFactory::createEPollReactor(size);
  socket_ = -1;
}

TCPServer::~TCPServer() {
  if (!isInitialized()) {
    return ;
  }

  if (reactor_) {
    ReactorFactory::destoryReactor(reactor_);
    reactor_ = nullptr;
  }
}

bool TCPServer::start() {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  ret_value = reactor_->start();

  return ret_value;
}

bool TCPServer::send(const int sockfd, const std::string& data) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  if (sockfd < 0) {
    return ret_value;
  }

  ret_value = reactor_->send(sockfd, data);

  return ret_value;
}

bool TCPServer::send(
    const int sockfd, const unsigned char* data, const int length) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  if (sockfd < 0) {
    return ret_value;
  }

  ret_value = reactor_->send(sockfd, data, length);

  return ret_value;
}

void TCPServer::stop() {
  if (!isInitialized()) {
    return ;
  }

  reactor_->stop();
}

bool TCPServer::listen(
    const std::string& address, const int port, EventListener* listener) {
  bool ret_value = false;

  if (!isInitialized()) {
    return ret_value;
  }

  if (socket_ > 0) {
    Log4cpp::getInstance().debug("reactor", "already listened...");

    return ret_value;
  }

  if (address.empty() || port <= 0 || !listener) {
    Log4cpp::getInstance().debug("reactor", "invalid parameters...");

    return ret_value;
  }

  int sock;
  struct sockaddr_in sockaddr;
  struct hostent *host;
  sock = socket(AF_INET,
           SOCK_STREAM,
           0);

  if(sock < 0) {
    return ret_value;
  }

  /* zero buffer */
  memset(&sockaddr, 0, sizeof(sockaddr));
  sockaddr.sin_family = AF_INET;

  if((host = gethostbyname(address.c_str())) == NULL) {
     close(sock);
     return ret_value;
  }

  memcpy(&sockaddr.sin_addr,
        host -> h_addr,
        host -> h_length );
  sockaddr.sin_port = htons(port);

  if (bind(sock, (struct sockaddr*)&sockaddr, sizeof(sockaddr)) < 0) {
    close(sock);
    return ret_value;
  }
  if (::listen(sock, 1024) < 0) {
    close(sock);
    return ret_value;
  }

  //make nonblocking.
  int flags = fcntl(sock, F_GETFL, 0);
  if (flags == -1) {
    close(sock);

    return ret_value;
  }
  flags = flags | O_NONBLOCK;
  fcntl(sock, F_SETFL, flags);

  //add fuel.
  Fuel* fuel = new Fuel();
  fuel->setSocket(sock);
  fuel->setType(CommonUtils::FUEL_TYPE_RAW);
  fuel->setReadBuffer(new SimpleBuffer());
  fuel->getReadBuffer()->setFuel(fuel);
  fuel->setWriteBuffer(new SimpleBuffer());
  fuel->getWriteBuffer()->setFuel(fuel);
  fuel->setListener(this);
  fuel->setAcceptable(true);
  listener_ = listener;
  if (!reactor_->add(fuel)) {
    close(sock);

    return ret_value;
  }
  socket_ = sock;

  Log4cpp::getInstance().debug("reactor", "listen %s:%d ok...socket_->%d",
   address.c_str(), port,
   socket_);

  ret_value = true;

  return ret_value;
}

void TCPServer::handleAccept(const int sockfd) {
  struct sockaddr_storage sockaddr;
  int addr_size = sizeof sockaddr;
  int new_sockfd = accept(sockfd, (struct sockaddr *)&sockaddr, (socklen_t*)&addr_size);

  //make nonblocking.
  int flags = fcntl(new_sockfd, F_GETFL, 0);
  if (flags == -1) {
    Log4cpp::getInstance().error("reactor", "get flag failed");

    close(new_sockfd);

    return ;
  }
  flags = flags | O_NONBLOCK;
  fcntl(new_sockfd, F_SETFL, flags);

  Fuel* fuel = new Fuel();
  fuel->setSocket(new_sockfd);
  fuel->setType(CommonUtils::FUEL_TYPE_RAW);
  fuel->setReadBuffer(new SimpleBuffer());
  fuel->getReadBuffer()->setFuel(fuel);
  fuel->getReadBuffer()->setSocketFd(new_sockfd);
  fuel->setWriteBuffer(new SimpleBuffer());
  fuel->getWriteBuffer()->setFuel(fuel);
  fuel->getWriteBuffer()->setSocketFd(new_sockfd);
  fuel->setListener(this);
  reactor_->add(fuel);
}

void TCPServer::handleClose(const int sockfd) {
  listener_->handleClose(sockfd);
}

void TCPServer::handleInput(Buffer& buffer) {
  listener_->handleInput(buffer);
}

void TCPServer::handleTimeout(const int sockfd) {
  listener_->handleTimeout(sockfd);
}

void TCPServer::handleError(const int errorId,
        const void* user_data, const int length) {
  listener_->handleError(errorId, user_data, length);
}

}
